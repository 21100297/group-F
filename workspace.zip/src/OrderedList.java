package Fold;

public class OrderedList extends ItemList{
	String temp_str1 = "";
	String temp_str2 = "";
	String temp_str3 = "";
	public OrderedList(String str_cur, int line, int count) {
		super(str_cur);
		//str_cur.trim();
		// TODO Auto-generated constructor stub
		if(line == 0){
			temp_str1 = "<li>";
			temp_str2 = str_cur.substring(count+2);
			temp_str3 = "</li>";
		}	
		else if(line == 1){
			temp_str1 = "<ol><li>";
			temp_str2 = str_cur.substring(count+2);
			temp_str3 = "</li>";
		}
		else if(line == 2){
			temp_str1 = "<ol><li>";
			temp_str2 = str_cur.substring(count+2);
			temp_str3 = "</li></ol>";
		}
		else if(line == 3){
			temp_str1 = "<li>";
			temp_str2 = str_cur.substring(count+2);
			temp_str3 = "</li></ol>";
		}
		str_cur = temp_str1+temp_str2+temp_str3;
		System.out.println(str_cur);
	}

}

package Fold;

public class StyleText extends Tokens{

}

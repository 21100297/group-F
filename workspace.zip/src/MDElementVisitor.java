package Fold;

public interface MDElementVisitor {
	public void visitDocument(Document document);
	public void visitNode(Node node);
	public void visitTokens(Tokens tokens);
	public void visitHeader(Header header);
	public void visitSetext(Setext setext);
	public void visitAtx(Atx atx);
	public void visitBlock(Block block);
	public void visitQuotedBlock(QuotedBlock quotedBlock);
	public void visitItemList(ItemList itemList);
	public void visitOrderedList(OrderedList orderedList);
	public void visitUnorderedList(UnorderedList unorderedList);
	public void visitCodeBlock(CodeBlock codeBlock);
	public void visitPlainText(PlainText plainText);
	
}

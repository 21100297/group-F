package Fold;

public class Header extends Node{

	public Header(String str_cur, int count) {
		super(str_cur);
		// TODO Auto-generated constructor stub
		if(count==1){      
	    	str_cur="<h1>"+str_cur.substring(1)+"</h1>";
	    }else if(count==2){
	    	str_cur="<h2>"+str_cur.substring(2)+"</h2>";
	    }else if(count==3){
	    	str_cur="<h3>"+str_cur.substring(3)+"</h3>";
	    }else if(count==4){
	    	str_cur="<h4>"+str_cur.substring(4)+"</h4>";
	    }else if(count==5){
	    	str_cur="<h5>"+str_cur.substring(5)+"</h5>";
	    }else if(count==6){
	    	str_cur="<h6>"+str_cur.substring(6)+"</h6>";
	    }else if(count==7){
	    	str_cur="<h1>"+str_cur+"</h1>";
	    }else if(count==8){
	    	str_cur="<h2>"+str_cur+"</h2>";
	    }
		System.out.println(str_cur);
	}
	
	public Header(String str_cur){
		super(str_cur);
	}

}

package Fold;

import java.io.BufferedWriter;
import java.io.FileNotFoundException;
import java.io.FileWriter;
import java.io.IOException;
import java.io.File;

public class PlainVisitor implements MDElementVisitor{
	
	
	public void visitDocument(Document document){
		String str="";
		
		Document exDocument=new Document();
		str=exDocument.getName();
		
		System.out.println("File Name: "+str);
		System.out.print("Style: Plain Style");
	}
	public void visitNode(Node node){
		System.out.println("��� �湮��");
	}
	public void visitTokens(Tokens tokens){
		System.out.println("��ū �湮��");
	}
	@Override
	public void visitHeader(Header header) {
		// TODO Auto-generated method stub
		
	}
	@Override
	public void visitSetext(Setext setext) {
		// TODO Auto-generated method stub
		
	}
	@Override
	public void visitAtx(Atx atx) {
		// TODO Auto-generated method stub
		
	}
	@Override
	public void visitBlock(Block block) {
		// TODO Auto-generated method stub
		
	}
	@Override
	public void visitQuotedBlock(QuotedBlock quotedBlock) {
		// TODO Auto-generated method stub
		
	}
	@Override
	public void visitItemList(ItemList itemList) {
		// TODO Auto-generated method stub
		
	}
	@Override
	public void visitOrderedList(OrderedList orderedList) {
		// TODO Auto-generated method stub
		
	}
	@Override
	public void visitUnorderedList(UnorderedList unorderedList) {
		// TODO Auto-generated method stub
		
	}
	@Override
	public void visitCodeBlock(CodeBlock codeBlock) {
		System.out.println("�ڵ���� ������");
		// TODO Auto-generated method stub
		
	}
	@Override
	public void visitPlainText(PlainText plainText) {
		// TODO Auto-generated method stub
		
	}
}

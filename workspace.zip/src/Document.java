package Fold;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
//import java.util.LinkedList;
import java.util.List;

public class Document implements MDElement{
	ArrayList<Node> document = new ArrayList<Node>();
	//private String str_cur="", str_prev = "";
	private int i;
	private int check_prev, check_cur, check_next, line; // For CodeBlock. 
	private int check_cb; // For CodeBlock. tab or space mode check
	private int l_prev = 0;
	private int l_cur = 0;
	private int l_next = 0;
	private int count_atx, count_set, check_ds; // For Header.
	private int check_quo; // For QuotedBlock
	private int count_int_prev, count_int_cur, count_int_next, check_dot_prev, check_dot_cur, check_dot_next; // For ItemList
	private int check_block; // For Block
	
	String str_prev = ""; // ���� ��
	String str_cur = ""; // ���� ��
	String str_next = ""; // ���� ��
		
	public void accept(MDElementVisitor a){
		a.visitDocument(this);
	}
	
	public void Fname(String name) throws IOException{
			
		try{
			FileReader f_reader = new FileReader(name);
			BufferedReader b_reader = new BufferedReader(f_reader, 1024);
			
			while((str_next = b_reader.readLine()) != null){
				
				check_prev = 0;
				check_cur = 0;
				check_next = 0;
				check_cb = 0;
				line = 0;
				count_atx = 0;
				count_set = 0;
				check_ds = 0;
				check_quo = 0;
				count_int_prev = 0;
				count_int_cur = 0;
				count_int_next = 0;
				check_dot_prev = 0;
				check_dot_cur = 0;
				check_dot_next = 0;
				check_block = 0;		
				l_prev = str_prev.length();
				l_cur = str_cur.length();
				l_next = str_next.length();
				
				/* QuotedBlock */
			    for(i=0;i<str_cur.length();i++){
			    	if(str_cur.charAt(i)=='>')
			    		check_quo++;
			    	else
			    		break;	
			    }
			    if(check_quo>0){
			    	document.add(new QuotedBlock(str_cur, check_quo));
			    	check_block = 1;
			    }
			    else {
			    	/* CodeBlock ���� */
					for(i=0;i<l_prev;i++){
						if(i == 4)
							break;
						if(str_prev.charAt(i) == ' ')
							check_prev++;	
					}
					
					for(i=0;i<l_cur;i++){
						if(i == 4)
							break;
						if(str_cur.charAt(i) == ' ')
							check_cur++;	
					}	
					
					for(i=0;i<l_next;i++){
						if(i == 4)
							break;
						if(str_next.charAt(i) == ' ')
							check_next++;	
					}
					
					if(!(str_next.isEmpty()) && (str_next.charAt(0) == '\t' || check_next == 4)){ // ���� CodeBlock
						if(!(str_cur.isEmpty()) && (str_cur.charAt(0) == '\t' || check_cur == 4)){ // ���� CodeBlock
							if(str_cur.charAt(0) == '\t')
								check_cb = 1; // tab
							else if(check_cur == 4)
								check_cb = 2; // ������� 4��
							
							if(str_prev.isEmpty() || !(str_prev.charAt(0) == '\t' || check_prev == 4)){ // ���� ��ų� CodeBlock �ƴҶ�
								document.add(new CodeBlock(str_cur, line, check_cb)); // line = 0
								check_block = 1;
							}
							else{ // ���ٵ� CodeBlock
								line = 1; // ���ٵ� CodeBlock
								document.add(new CodeBlock(str_cur, line, check_cb)); // line = 1
								check_block = 1;
							}
						}
					}
					else{ // ���� �Ϲ���
						if(!(str_cur.isEmpty()) && (str_cur.charAt(0) == '\t' || check_cur == 4)){ // ���� CodeBlock
							if(str_cur.charAt(0) == '\t')
								check_cb = 1; // tab
							else if(check_cur == 4)
								check_cb = 2; // ������� 4��
							
							if(str_prev.isEmpty() || !(str_prev.charAt(0) == '\t' || check_prev == 4)){ // ���� ��ų� CodeBlock �ƴҶ�
								line = 2;
								document.add(new CodeBlock(str_cur, line, check_cb)); // line = 2
								check_block = 1;
							}
							else{
								line = 3; // ���ٵ� CodeBlock
								document.add(new CodeBlock(str_cur, line, check_cb)); // line = 3
								check_block = 1;
							}	
						}
						else{
							/* Header ���� */
							
							//atx					
							for(int i=0; i<l_cur; i++){      //atx type header
								if(str_cur.trim().charAt(i)=='#'){  //checking front#
						        	count_atx++;
						        }else if(i==6 || str_cur.trim().charAt(i)!='#'){
						        	break;
						        }
							}    
						    
						    if((count_atx > 0) && (count_atx < 7)){      
						    	document.add(new Header(str_cur.trim(), count_atx));
						    	check_block = 1;
						    }
						    //setext
						    else{ 
						    	for(i=0; i<l_next; i++){
							    	if(str_next.trim().charAt(i)=='=')
							    		count_set++;
							    	else
							    		break;
							    }
						    	
						    	if(count_atx == 0 && !(str_cur.isEmpty())){ // #�� ���� string
						    		if((count_set != 0) && (count_set == l_next)){
						    			check_ds = 7;
						    			document.add(new Header(str_cur.trim(), check_ds));
						    			check_block = 1;
						    	    }
						    	}

						    	if(count_set == 0){
						    		for(i=0; i<l_next; i++){
						    			if(str_next.trim().charAt(i)=='-')
						    				count_set++;
						    			else
						    				break;
						    		}
						    		if(count_atx == 0 && !(str_cur.isEmpty())){ // #�� ���� string
						    			if((count_set != 0) && (count_set == l_next)){
						    				check_ds = 8;
						    				document.add(new Header(str_cur.trim(), check_ds));
						    				check_block = 1;
						    			}
						    		}
						    	}
						    }
						    /* itemList ���� */
						    
						    // Ordered List
						    
						    for(i=0;i<str_cur.trim().length();i++){
						    	if(str_cur.trim().charAt(i)=='0' || str_cur.trim().charAt(i)=='1' || str_cur.trim().charAt(i)=='2' || str_cur.trim().charAt(i)=='3'
						    	   || str_cur.trim().charAt(i)=='4' || str_cur.trim().charAt(i)=='5' || str_cur.trim().charAt(i)=='6' 
						    	   || str_cur.trim().charAt(i)=='7' || str_cur.trim().charAt(i)=='8' || str_cur.trim().charAt(i)=='9'){
						    		count_int_cur++;					
						    	}
						    	else if((count_int_cur > 0) && str_cur.trim().charAt(i)=='.'){
						    		check_dot_cur = i;
						    		break;
						    	}
						    	else
						    		break;
						    }
						    
						    for(i=0;i<str_prev.trim().length();i++){
						    	if(str_prev.trim().charAt(i)=='0' || str_prev.trim().charAt(i)=='1' || str_prev.trim().charAt(i)=='2' || str_prev.trim().charAt(i)=='3'
						    	   || str_prev.trim().charAt(i)=='4' || str_prev.trim().charAt(i)=='5' || str_prev.trim().charAt(i)=='6'
						    	   || str_prev.trim().charAt(i)=='7' || str_prev.trim().charAt(i)=='8' || str_prev.trim().charAt(i)=='9')
						    		count_int_prev++;
						    	else if((count_int_prev > 0) && str_prev.trim().charAt(i)=='.'){
						    		check_dot_prev = i;
						    		break;
						    	}
						    	else
						    		break;
						    }
						    
						    for(i=0;i<str_next.trim().length();i++){
						    	if(str_next.trim().charAt(i)=='0' || str_next.trim().charAt(i)=='1' || str_next.trim().charAt(i)=='2' || str_next.trim().charAt(i)=='3'
						    	   || str_next.trim().charAt(i)=='4' || str_next.trim().charAt(i)=='5' || str_next.trim().charAt(i)=='6'
						    	   || str_next.trim().charAt(i)=='7' || str_next.trim().charAt(i)=='8' || str_next.trim().charAt(i)=='9')
						    		count_int_next++;
						    	else if((count_int_cur > 0) && str_next.trim().charAt(i)=='.'){
						    		check_dot_next = i;
						    		break;
						    	}
						    	else
						    		break;
						    }

						    if(count_int_cur != 0 && ((count_int_cur) == check_dot_cur)){	
						    		if((!(str_prev.length()==0) && ((count_int_prev) == check_dot_prev) && (count_int_prev > 0)) && (!(str_next.length()==0) && ((count_int_next) == check_dot_next) && count_int_next > 0)){
								    	line = 0; //��, �ڵ� Ordered
								    	document.add(new OrderedList(str_cur.trim(), line, count_int_cur));
								    	check_block = 1;
								    }
								    else if(((str_prev.length()==0) || !((count_int_prev) == check_dot_prev) || (count_int_prev == 0)) && (!(str_next.length()==0) && ((count_int_next) == check_dot_next))){
								    	line = 1; //���� �Ϲ�, �ڴ� Ordered
								    	document.add(new OrderedList(str_cur.trim(), line, count_int_cur));
								    	check_block = 1;
								    }
								    else if(((str_prev.length()==0) || !((count_int_prev) == check_dot_prev) || (count_int_prev == 0)) && ((str_next.length()==0) || !((count_int_next) == check_dot_next))){
								    	line = 2; // ȥ�ڼ� Ordered
								    	document.add(new OrderedList(str_cur.trim(), line, count_int_cur));
								    	check_block = 1;
								    }
								    else if((!(str_prev.length()==0) && ((count_int_prev) == check_dot_prev) && (count_int_prev > 0)) && ((str_next.length()==0) || !((count_int_next) == check_dot_next) || (count_int_next == 0))){
								    	line = 3; // �� Ordered, �� �Ϲ�
								    	document.add(new OrderedList(str_cur.trim(), line, count_int_cur));
								    	check_block = 1;
								    }				  
						    }
						     // Unordered List				 			    
						} // ���� ���� CodeBlock�� �ƴ�.
					} // nextLine�� CodeBlock�� �ƴ�.
					
			    } // QuotedBlock�� �ƴ�.
			    document.add(new Block(str_cur, check_block));	    
			  		    
			    str_prev = str_cur;
				str_cur = str_next;				
			}
			b_reader.close();
			f_reader.close();
		} catch(FileNotFoundException e){
			System.out.println("������ �̸��� ��Ȯ�� �Է��� �ֽʽÿ�.");
			e.printStackTrace();
		} catch(IOException e){
			e.printStackTrace();
		}				
	}
	
	public Document() {
		
	}
	
	public String getName(){
		return "dadad";
	}
	
}

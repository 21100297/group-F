package Fold;

public interface MDElement {
	public void accept(MDElementVisitor a);
}

package Fold;

public class Atx extends Header {

	public Atx(String str) {
		super(str);
		// TODO Auto-generated constructor stub
	}

}

package Fold;

public class UnorderedList extends ItemList{

	public UnorderedList(String str) {
		super(str);
		// TODO Auto-generated constructor stub
	}

}

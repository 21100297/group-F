package Fold;

public class QuotedBlock extends Node {
	
	private int i;
	private String temp_str1, temp_str2;
	
	public QuotedBlock(String str_cur, int check_quo) {
		super(str_cur);
		temp_str1 = "";
		temp_str2 = "";
		// TODO Auto-generated constructor stub
		
		for(i=0; i<check_quo; i++){
			if(i == 0)
				temp_str1 = "\t";
			else
				temp_str1 += "\t";
		}
		temp_str2 = str_cur.substring(check_quo);
		str_cur = temp_str1+temp_str2;
		System.out.println(str_cur);
	}
	
}

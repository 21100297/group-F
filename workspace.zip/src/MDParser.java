package Fold;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
//import java.util.Scanner;
//import java.lang.Integer;
/*
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
*/

public class MDParser {
	public static void main(String[] args) throws java.io.IOException
	{
		PlainVisitor plain = new PlainVisitor();
		/*FileReader f_reader = null;
		String str_prev = ""; // ���� ��
		String str_cur = ""; // ���� ��
		String str_next = ""; // ���� ��*/
		Command command=new Command();
		Document document=new Document();
		String f_name="";	
		String style="";				
		// command�� �޴´�. ==========================================
				try{
					command.visitCommand(args[0]);
				}
				catch(Exception v){
					System.out.println("Please Input command.");
					return;
				}
			//===============================================================
				try{
					f_name=args[1];
					FileReader fileReader=new FileReader(f_name);
					BufferedReader read=new BufferedReader(new FileReader(f_name));			
				}
				catch (FileNotFoundException a) {
					System.out.println("Input right file name");
					return;
				}
			//================================================================
				
				style=args[2];
				if(args[2].equals(style))
				{
					document.Fname(args[1]);
					plain.visitDocument(document);
				}
				else{
					if(style.equals("plain")){
						System.out.print("Style: Plain Style");
						// plain class
					}
					else if(style.equals("fancy")){
						System.out.print("Style: Fancy Style");
						// fancy class
					}
					else if(style.equals("slide")){
						System.out.print("Style: Slide Style");
						// slide class
					}
					else{
						System.out.print("Please, Input right type.");
					}	
				}
	}
}

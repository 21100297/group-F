package Fold;

public class FancyVisitor implements MDElementVisitor{
	public void visitDocument(Document document){}
	public void visitNode(Node node){}
	public void visitTokens(Tokens tokens){}
	@Override
	public void visitHeader(Header header) {
		// TODO Auto-generated method stub
		
	}
	@Override
	public void visitSetext(Setext setext) {
		// TODO Auto-generated method stub
		
	}
	@Override
	public void visitAtx(Atx atx) {
		// TODO Auto-generated method stub
		
	}
	@Override
	public void visitBlock(Block block) {
		// TODO Auto-generated method stub
		
	}
	@Override
	public void visitQuotedBlock(QuotedBlock quotedBlock) {
		// TODO Auto-generated method stub
		
	}
	@Override
	public void visitItemList(ItemList itemList) {
		// TODO Auto-generated method stub
		
	}
	@Override
	public void visitOrderedList(OrderedList orderedList) {
		// TODO Auto-generated method stub
		
	}
	@Override
	public void visitUnorderedList(UnorderedList unorderedList) {
		// TODO Auto-generated method stub
		
	}
	@Override
	public void visitCodeBlock(CodeBlock codeBlock) {
		// TODO Auto-generated method stub
		
	}
	@Override
	public void visitPlainText(PlainText plainText) {
		// TODO Auto-generated method stub
		
	}
}

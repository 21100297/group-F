package Fold;

public class CodeBlock extends Node {
	//char[] ch = null;
	String temp_str1 = "";
	String temp_str2 = "";
	public CodeBlock(String str_cur, int line, int check_cb) {
		super(str_cur);
		if(line == 0){
			if(check_cb == 1){
				temp_str1 = "<pre><code>";
				temp_str2 = str_cur.substring(1);
			}	
			else if(check_cb == 2){
				temp_str1 = "<pre><code>";
				temp_str2 = str_cur.substring(4);
			}
			str_cur = temp_str1+temp_str2;
		}
		else if(line == 1){
			if(check_cb == 1){
				temp_str1 = "";
				temp_str2 = str_cur.substring(1);
			}	
			else if(check_cb == 2){
				temp_str1 = "";
				temp_str2 = str_cur.substring(4);
			}
			str_cur = temp_str1+temp_str2;
		}
		else if(line == 2){
			if(check_cb == 1){
				temp_str1 = "<pre><code>";
				temp_str2 = str_cur.substring(1);
			}	
			else if(check_cb == 2){
				temp_str1 = "<pre><code>";
				temp_str2 = str_cur.substring(4);
			}
			str_cur = temp_str1+temp_str2+"</code></pre>";
		}
		else{
			if(check_cb == 1){
				temp_str1 = "";
				temp_str2 = str_cur.substring(1);
			}	
			else if(check_cb == 2){
				temp_str1 = "";
				temp_str2 = str_cur.substring(4);
			}
			str_cur = temp_str1+temp_str2+"</code></pre>";
		}
		System.out.println(str_cur);
	}

	public void accept(MDElementVisitor a){
		a.visitNode(this);
	}
	
	public CodeBlock create(String a){
		
		return null;
	}
}

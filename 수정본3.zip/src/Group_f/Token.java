package Group_f;

public class Token<Token> implements MDElement {

	
	public void accept(MDElementVisitor visitor) {
	}

}

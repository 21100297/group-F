package Group_f;

public class PlainVisitor implements MDElementVisitor {

	//READ MD FILE
	public void visitDocument(Document document) {
		System.out.print("Style: Plain Style\n");
	}

	//Separate Node
	public void visitNode(Node node) {
		System.out.println("We separate string to Node!");
	}

}

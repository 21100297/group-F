package Group_f;

import Group_f.Node.node;

public class ltemList extends Node<String> {
	
	private String af_string;
	
	
	public void itemlist(Node<String> contents){
		
		OrderedList OL =new OrderedList();
		
		
		node temp=contents.head;
		node prev=null;
		
		int count_int_cur=0;
		int check_dot_cur=0;
		int count_int_prev=0;
		int check_dot_prev=0;
		int count_int_next=0;
		int check_dot_next=0;
		int line=0;
		af_string="";
		
		while(temp!=null){
			if(temp.prev!=null&&temp.next!=null){
				for(int i=0;i<temp.data.trim().length();i++){
					if(temp.data.trim().charAt(i)=='0' || temp.data.trim().charAt(i)=='1' || temp.data.trim().charAt(i)=='2' || temp.data.trim().charAt(i)=='3'
							|| temp.data.trim().charAt(i)=='4' || temp.data.trim().charAt(i)=='5' || temp.data.trim().charAt(i)=='6' 
							|| temp.data.trim().charAt(i)=='7' || temp.data.trim().charAt(i)=='8' || temp.data.trim().charAt(i)=='9'){
						count_int_cur++;	
					}
					else if((count_int_cur > 0) && temp.data.trim().charAt(i)=='.'){
						check_dot_cur = i;
						break;
					}
					else
						break;
				} // ���� ������ ���ڰ� �ִ��� ������ Ȯ�� 
    
				for(int i=0;i<temp.prev.data.trim().length();i++){
					if(temp.prev.data.trim().charAt(i)=='0' || temp.prev.data.trim().charAt(i)=='1' || temp.prev.data.trim().charAt(i)=='2' || temp.prev.data.trim().charAt(i)=='3'
							|| temp.prev.data.trim().charAt(i)=='4' || temp.prev.data.trim().charAt(i)=='5' || temp.prev.data.trim().charAt(i)=='6'
							|| temp.prev.data.trim().charAt(i)=='7' || temp.prev.data.trim().charAt(i)=='8' || temp.prev.data.trim().charAt(i)=='9')
						count_int_prev++;
					else if((count_int_prev > 0) && temp.prev.data.trim().charAt(i)=='.'){
						check_dot_prev = i;
						break;
					}
					else
						break;
				} //�� ���ٿ� ���ڰ� �ִ��� üũ
    
				for(int i=0;i<temp.next.data.trim().length();i++){
					if(temp.next.data.trim().charAt(i)=='0' || temp.next.data.trim().charAt(i)=='1' || temp.next.data.trim().charAt(i)=='2' || temp.next.data.trim().charAt(i)=='3'
							|| temp.next.data.trim().charAt(i)=='4' || temp.next.data.trim().charAt(i)=='5' || temp.next.data.trim().charAt(i)=='6'
							|| temp.next.data.trim().charAt(i)=='7' || temp.next.data.trim().charAt(i)=='8' || temp.next.data.trim().charAt(i)=='9')
						count_int_next++;
					else if((count_int_cur > 0) && temp.next.data.trim().charAt(i)=='.'){
						check_dot_next = i;
						break;
					}
					else
						break;
				}// �����ٿ� ���ڰ� �ִ��� ������ üũ

				if(count_int_cur != 0 && ((count_int_cur) == check_dot_cur)){	
					if((!(temp.prev.data.length()==0) && ((count_int_prev) == check_dot_prev) && (count_int_prev > 0)) && (!(temp.next.data.length()==0) && ((count_int_next) == check_dot_next) && count_int_next > 0)){
						line = 0; //��, �ڵ� Ordered
						af_string=OL.OrderedList(temp.data, line, count_int_cur);
						temp.data=af_string;
					}
					else if(((temp.prev.data.length()==0) || !((count_int_prev) == check_dot_prev) || (count_int_prev == 0)) && (!(temp.next.data.length()==0) && ((count_int_next) == check_dot_next))){
						line = 1; //���� plain, �ڴ� Ordered
						af_string=OL.OrderedList(temp.data, line, count_int_cur);
						temp.data=af_string;
					}
					else if(((temp.prev.data.length()==0) || !((count_int_prev) == check_dot_prev) || (count_int_prev == 0)) && ((temp.next.data.length()==0) || !((count_int_next) == check_dot_next))){
						line = 2; // ȥ�ڼ� Ordered
						af_string=OL.OrderedList(temp.data, line, count_int_cur);
						temp.data=af_string;
					}
					else if((!(temp.prev.data.length()==0) && ((count_int_prev) == check_dot_prev) && (count_int_prev > 0)) && ((temp.next.data.length()==0) || !((count_int_next) == check_dot_next) || (count_int_next == 0))){
						line = 3; // �� Ordered, �� plain
						af_string=OL.OrderedList(temp.data, line, count_int_cur);
						temp.data=af_string;
					}		  
				}// ��ȯ�Ϸ�
			} // ����������� ���� ��� if�� ����
			
			prev=temp;
			temp=temp.next;
			if(temp.next==null) break; // ������ ������� �� ������ break�� �������´�. ���� �ʱ�ȭ �����ֱ� 
			
			count_int_cur=0;
			check_dot_cur=0;
			count_int_prev=0;
			check_dot_prev=0;
			count_int_next=0;
			check_dot_next=0;
			line=0;
			af_string="";
    	} // ��ü ������ �� �д� �� ����
		
	} // ����Ʈ �˻� ��

} // ��ü class ��
	
	


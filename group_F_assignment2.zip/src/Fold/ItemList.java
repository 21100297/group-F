package Fold;

public class ItemList extends Node{

	public ItemList(String str) {
		super(str);
		// TODO Auto-generated constructor stub
	}

}

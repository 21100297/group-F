package Fold;

public class Block extends Node{

	public Block(String str_cur, int check_block) {
		super(str_cur);
		if(check_block == 0)
			System.out.println(str_cur);
	}

}

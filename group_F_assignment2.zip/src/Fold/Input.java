package Fold;

import java.io.*;


public class Input {
	
	public void inputCommand(String Command){
		if(Command.equals("-help")){
			System.out.println("help");
			return;
		}
		else if(Command.equals("-read")){
			System.out.println("������ �е��� �ϰڽ��ϴ�.");
		}
	}
	
	public void findDocument(String document) {
			try {
				BufferedReader read = new BufferedReader(new FileReader(document));
				System.out.println("File name: "+document);
				return;
			} catch (FileNotFoundException a) {
				System.out.println("������ �̸��� ��Ȯ�� �Է��� �ֽʽÿ�.");
				return; 
			}
	}

	public void selectStyle(String Node) {
		// TODO Auto-generated method stub
		if(Node.equals("plain")||Node.equals(null)){
			System.out.print("Style: Plain Style");
			// plain class
		}
		else if(Node.equals("fancy")){
			System.out.print("Style: Fancy Style");
			// fancy class
		}
		else if(Node.equals("slide")){
			System.out.print("Style: Slide Style");
			// slide class
		}
		else{
			System.out.print("Please, Input right type.");}	
	}

	
}



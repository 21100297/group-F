package Fold;

import java.util.ArrayList;
//import java.lang.Integer;
//import java.lang.NumberFormatException;

public class Node implements MDElement{
	
	ArrayList<Tokens> node = new ArrayList<Tokens>();
	int i;
	
	public Node(String str_cur){
		
	}
	
	public Node(String str_prev, String str_cur, int line){
		
	}
	
	public void accept(MDElementVisitor a){
		a.visitNode(this);
	}
	
	public Node create(String a){
		return null;
		
		//Tokens t = new Tokens();
		//return n;
	}
}

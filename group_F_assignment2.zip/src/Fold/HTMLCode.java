package Fold;

public class HTMLCode extends Tokens{

}

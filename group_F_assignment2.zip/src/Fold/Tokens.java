package Fold;

public class Tokens implements MDElement{
	
	public Tokens(){
		
	}
	
	public void accept(MDElementVisitor a){
		a.visitTokens(this);
	}
}

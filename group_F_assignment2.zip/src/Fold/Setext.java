package Fold;

public class Setext extends Header {

	public Setext(String str) {
		super(str);
		// TODO Auto-generated constructor stub
	}

}

package Fold;

public class PlainText extends Tokens{
	
}
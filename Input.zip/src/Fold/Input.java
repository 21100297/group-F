package Fold;

import java.io.*;

public class Input implements MDElementVisitor {

	@Override
	public void visitDocument(String Document) {
		if(Document.equals("-help")){
			System.out.println("This is help message.");
		}
		else if(Document.equals(null)){
			System.out.println("Please Input file name.");
		}
		
		else{
			try {
				new BufferedReader(new FileReader(Document));
			} catch (FileNotFoundException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}

		
	}

	@Override
	public void visitNode(String Node) {
		// TODO Auto-generated method stub
		if(Node.equals("plain")){
			System.out.print("This is Plain Style");
			// plain class
		}
		else if(Node.equals("fancy")){
			System.out.print("This is Fancy Style");
			// fancy class
		}
		else if(Node.equals("slide")){
			System.out.print("This is Slide Style");
			// slide class
		}
		else{
			System.out.print("Please, Input right type.");}	
	}
}



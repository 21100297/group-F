package Fold;

public class File {
	public static void main(String[] args) throws java.io.IOException
	{
		Input data=new Input();
		data.visitDocument(args[0]);
		data.visitNode(args[1]);
	}
}



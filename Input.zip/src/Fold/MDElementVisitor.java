package Fold;

public interface MDElementVisitor {
	void visitDocument(String Document);
	void visitNode(String Node);
}

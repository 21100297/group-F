package Group_f;

public class PlainText extends Token{


}

package Group_f;

public class OrderedList extends ltemList {
	// ������ ����Ʈ ��Ÿ���������������������� l->L�� 
	
	String temp_str1 = "";
	String temp_str2 = "";
	String temp_str3 = "";
	
	public String OrderedList(String str_cur, int line, int count) {
		if(line == 0){
			temp_str1 = "<li>";
			temp_str2 = str_cur.substring(count+2);
			temp_str3 = "</li>";
		}	
		else if(line == 1){
			temp_str1 = "<ol><li>";
			temp_str2 = str_cur.substring(count+2);
			temp_str3 = "</li>";
		}
		else if(line == 2){
			temp_str1 = "<ol><li>";
			temp_str2 = str_cur.substring(count+2);
			temp_str3 = "</li></ol>";
		}
		else if(line == 3){
			temp_str1 = "<li>";
			temp_str2 = str_cur.substring(count+2);
			temp_str3 = "</li></ol>";
		}
		str_cur = temp_str1+temp_str2+temp_str3;
		
		return str_cur;
	}
		
}

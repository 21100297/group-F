package Group_f;

public class Image extends Token{
	   public String image(String data){ // ![Alt text](/path/to/img.jpg)
        //   [id]: url/to/image    �̹��� syntax.  [id] �Ⱦ��ٰ� ����
		   String a="";
		   String temp1="", temp2="", temp3="", temp4="";
		   
		   int str_length = data.length();
		   for(int i=0; i<str_length;i++){
			   if(i==str_length-4)
				   break;
			   else if(data.charAt(i)=='!' && data.charAt(i+1)=='['){
				   for(int j=i+2; j<str_length;j++){
					   if(j==str_length-2)
						   break;
					   else if(data.charAt(j)==']'&& data.charAt(j+1)=='(' && j!=i+2){
						   for(int m=j+2; m<str_length; m++){
							   if(data.charAt(m)==')' && m!=j+2){ // ����. �� ��츸 �����Ѵٰ� ����
								   temp1=data.substring(0,i); 
								   temp2="<img alt="+'"' + data.substring(i+2,j) + '"'; 
								   temp3="src="+'"'+data.substring(j+2,m)+'"'+">"; 
								   temp4=data.substring(m+1);
							   }								 
						   }
					   }
					   /*else if(data.charAt(j)==']'&& data.charAt(j+1)=='[' && j!=i+2){
						   for(int n=j+2; n<str_length; n++){
							   if(data.charAt(n)==']' && n!=j+2){ // ����. �Ⱦ��ٰ� ����
								   
							   }
						   }
					   }*/						   
				   }
			   }				   
		   }
		   a = temp1+temp2+temp3+temp4;
		   if(!a.equals(""))
			   return a;
		   return data;
	   }
}
package Group_f;

public class UnorderedList extends ltemList {

	 private String temp_str1 = "";
	 private String temp_str2 = "";
	 private String temp_str3 = "";
	 private String af_string;
	 
	 public String unorderedlist(String str_cur, int line) {
	      //str_cur.trim();
	      if(line == 0){
	         temp_str1 = "<ul><li>";
	         temp_str2 = str_cur.substring(2);
	         temp_str3 = "</li></ul>";
	      }   
	      else if(line == 1){
	         temp_str1 = "<ul><li>";
	         temp_str2 = str_cur.substring(2);
	         temp_str3 = "</li>";
	      }
	      else if(line == 2){
	         temp_str1 = "<li>";
	         temp_str2 = str_cur.substring(2);
	         temp_str3 = "</li></ul>";
	      }
	      else if(line == 3){
	         temp_str1 = "<li>";
	         temp_str2 = str_cur.substring(2);
	         temp_str3 = "</li>";
	      }
	      str_cur = temp_str1+temp_str2+temp_str3;
	      af_string = str_cur;
	      
	      return af_string;
	   }
 
	
	
	
}

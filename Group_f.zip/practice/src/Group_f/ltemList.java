package Group_f;

public class ltemList extends Node<String> {
	
	private String af_string;
	public String str="";
	//private String temp_str1;
	//private String temp_str2;
	private String str_cur, str_prev, str_next;
	
	
	public void itemlist(Node<String> contents){
		
		OrderedList OL =new OrderedList();
		//UnorderedList UL =new UnorderedList();
		
		node temp=contents.head;
		//node prev=null;
		
		int count_int_cur=0;
		int check_dot_cur=0;
		int count_int_prev=0;
		int check_dot_prev=0;
		int count_int_next=0;
		int check_dot_next=0;
		int line=0;
		int cur =0;
		af_string="";
		System.out.println(2);
		while(temp!=null){
			
			str_prev="";
         	str_cur="";
         	str_next="";
         	if(temp.prev!=null){
				str_prev=temp.prev.data;
				
         	}
         	System.out.println(str_prev);
			str_cur=temp.data;
			if(temp.next!=null)
				str_next=temp.next.data;
			//System.out.println(3);
			if(!str_cur.isEmpty()){
				//if(temp.prev!=null&&temp.next!=null){
					for(int i=0;i<str_cur.trim().length();i++){
						if(str_cur.trim().charAt(i)=='0' || str_cur.trim().charAt(i)=='1' || str_cur.trim().charAt(i)=='2' || str_cur.trim().charAt(i)=='3'
					    	   || str_cur.trim().charAt(i)=='4' || str_cur.trim().charAt(i)=='5' || str_cur.trim().charAt(i)=='6' 
					    	   || str_cur.trim().charAt(i)=='7' || str_cur.trim().charAt(i)=='8' || str_cur.trim().charAt(i)=='9'){
					    		count_int_cur++;					
					    }
					   	else if((count_int_cur > 0) && str_cur.trim().charAt(i)=='.'){
					   		check_dot_cur = i;
					   		break;
					   	}
				    	else
				    		break;
					} // ���� ������ ���ڰ� �ִ��� ������ Ȯ�� 				
					
					for(int i=0;i<str_next.trim().length();i++){
				    	if(str_next.trim().charAt(i)=='0' || str_next.trim().charAt(i)=='1' || str_next.trim().charAt(i)=='2' || str_next.trim().charAt(i)=='3'
				    	   || str_next.trim().charAt(i)=='4' || str_next.trim().charAt(i)=='5' || str_next.trim().charAt(i)=='6'
				    	   || str_next.trim().charAt(i)=='7' || str_next.trim().charAt(i)=='8' || str_next.trim().charAt(i)=='9')
				    		count_int_next++;
				    	else if((count_int_cur > 0) && str_next.trim().charAt(i)=='.'){
				    		check_dot_next = i;
				    		break;
				    	}
				    	else
				    		break;
				    }// �����ٿ� ���ڰ� �ִ��� ������ üũ
					
					if(count_int_cur != 0 && ((count_int_cur) == check_dot_cur)){	
						if( cur == 1 && (!(str_next.length()==0) && ((count_int_next) == check_dot_next) && count_int_next > 0)){
							line = 0; //��, �ڵ� Ordered
							af_string=OL.OrderedList(str_cur.trim(), line, count_int_cur);
							temp.data=af_string;
							cur = 1;
						}
						else if(cur == 0 && (!(str_next.length()==0) && ((count_int_next) == check_dot_next))){
							line = 1; //���� plain, �ڴ� Ordered
							af_string=OL.OrderedList(str_cur.trim(), line, count_int_cur);
							temp.data=af_string;
						}
						else if(cur == 0 && ((str_next.length()==0) || !((count_int_next) == check_dot_next))){
							line = 2; // ȥ�ڼ� Ordered
							af_string=OL.OrderedList(str_cur.trim(), line, count_int_cur);
							temp.data=af_string;
							cur = 1;
						}
						else if(cur == 1 && ((str_next.length()==0) || !((count_int_next) == check_dot_next) || (count_int_next == 0))){
							line = 3; // �� Ordered, �� plain
							af_string=OL.OrderedList(str_cur.trim(), line, count_int_cur);
							temp.data=af_string;
						}		  
					}// ��ȯ�Ϸ�
				} // ����������� ���� ��� if�� ����

				temp=temp.next;
			
				count_int_cur=0;
				check_dot_cur=0;
				count_int_prev=0;
				check_dot_prev=0;
				count_int_next=0;
				check_dot_next=0;
				line=0;
				af_string="";
			//} // ��ü ������ �� �д� �� ����
		}
	} // ����Ʈ �˻� ��

} // ��ü class ��
	
	


package Group_f;

public class Command {
public String command="";
	
	public void visitCommand(String Command){
		command=Command;
		if(command.equals("-help")){
			System.out.println("The command input line form : ");
			System.out.println("<Pakagename/java_filename> <-option> <MDFile Name> <Style>");
			System.out.println("option list");
			System.out.println("	-read : read file and exchange the MD file to HTML file.");
			return;
		}
		else if(command.equals("-read")){
			System.out.println("We will read Input File.");
		}
		else
		{
			System.out.println("Usage: <Pakagename/javafiename> <-option> <MDFile Name> <Style>");
			System.out.println("use -help for a list of possible options");
			return;
		}
	}
}

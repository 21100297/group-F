package Group_f;

public class StyleText extends Token {

   public String Emphasis(String str_c){
      //String[] str=new String(str_c).split(" ");

      StyleText_emphasis SE= new StyleText_emphasis();

      int e=0; 
      int w=0;
      for(e=0; e<10; e++){
    	  //System.out.println("e: " + e); 
    	  str_c=SE.emphasis(str_c,"","");
      }
      return str_c;
   }

}
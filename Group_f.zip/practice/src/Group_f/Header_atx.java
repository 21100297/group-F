package Group_f;

public class Header_atx extends Header{
	
	private String af_string;

	public String change_string(String bf_string,int count){
		
		af_string="";
		
		if(count==1){      
			af_string="<h1>"+bf_string.substring(1)+"</h1>";
	    }else if(count==2){
	    	af_string="<h2>"+bf_string.substring(2)+"</h2>";
	    }else if(count==3){
	    	af_string="<h3>"+bf_string.substring(3)+"</h3>";
	    }else if(count==4){
	    	af_string="<h4>"+bf_string.substring(4)+"</h4>";
	    }else if(count==5){
	    	af_string="<h5>"+bf_string.substring(5)+"</h5>";
	    }else if(count==6){
	    	af_string="<h6>"+bf_string.substring(6)+"</h6>";
	    }
		return af_string;		
	}
}

package Group_f;

public interface MDElementVisitor {
	void visitDocument(Document document);
	void visitNode(Node node);
}

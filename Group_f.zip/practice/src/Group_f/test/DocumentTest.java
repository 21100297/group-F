package Group_f.test;

//import static org.junit.Assert.*;

import java.io.BufferedReader;
import java.io.IOException;

import org.junit.Before;
import org.junit.Test;

//import Group_f.MDPaser;
import Group_f.Document;
import org.junit.After;

public class DocumentTest {

	private Document doc;
	   BufferedReader in = null;
	   
	   @Before
	   public void setup() {
	      
		   doc = new Document();
	       
	      System.out.println("setup");
	   }
	   
	   @After
		public void teardown() {
			System.out.println("teardown!!!");
		}

	
	@Test
	public void testFileRead() throws IOException {
		doc.FileRead("E:\\workspace\\practice\\src\\save.txt");
		
		//fail("Not yet implemented");
	}

	@Test
	public void testFileWriter() {
		//fail("Not yet implemented");
	}

	@Test
	public void testAccept() {
		//fail("Not yet implemented");
	}

}

package Group_f;

import java.io.*;


public class Document implements MDElement {
	public Node<String> content=new Node<String>();
	
	private String file_name="";
	
	public void FileRead(String name)throws IOException{
		
		CodeBlock CB=new CodeBlock();
		QuotedBlock QB=new QuotedBlock();
		Header HD=new Header();
		ltemList IL=new ltemList();
		HorizontalRules HR=new HorizontalRules();
		Block BL=new Block();
		Token TK = new Token();
		
		try{
			file_name=name;
			FileInputStream fileReader=new FileInputStream(file_name);
			BufferedReader read=new BufferedReader(new FileReader(file_name));
			
			String f_string="";			
			while((f_string=read.readLine())!= null) // ������ string�� �߶� �����մϴ� 
			{
				content.addLast(f_string);
			}
			
			// LIST���� �Ҵ� �޾Ƽ� ���ǿ� �´� �� �˻� 

			QB.quoted(content);
			CB.codeblock(content);
			HR.horizon(content);
			HD.header(content);
			BL.block(content);
			System.out.println(1);
			IL.itemlist(content);
			
			// ����Ʈ�� ������ Ȯ���Ѵ�. 
			//System.out.println(content);
			
			TK.token(content);
			content.addFirst("<html><body>");
	        content.addLast("</body></html>");
			System.out.println(content);
			FileWriter(file_name,content);

		}
		catch(FileNotFoundException e){
			System.out.println("������ �̸��� ��Ȯ�� �Է��� �ֽʽÿ�.");
			e.printStackTrace();
		} 		
		
	}
	
		
	 public void FileWriter(String File_name,Node<String> create_content)throws IOException {
	      
	      int find=File_name.indexOf('.');
	      
	      File_name=File_name.substring(0, find);
	      FileWriter reader=new FileWriter(File_name+".html");
	      
	      
	      try{
	      while(create_content.head!=null){ // ������ ���� 
	    	  reader.write(create_content.head.data);
	    	  create_content.head=content.head.next;
	      }
	      reader.close();
	      }
	      catch(IOException ex){
	      }
	 }
	
	
	public void accept(MDElementVisitor visitor){
			visitor.visitDocument(this);
		}
}

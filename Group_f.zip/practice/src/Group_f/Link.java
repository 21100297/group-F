package Group_f;

public class Link extends Token {

   public String Emphasis(String bf_string){
   //   String []str=new String(bf_string).split(" ");
      Link links = new Link();

   //   int w=0;
      int e=0;
   //   for(e=0; e<bf_string.length(); e++){
         bf_string=links(bf_string); //e�� ã�� ������
   //      if(Link.checkCase==2){
   //         w=e;
   //      }
   //   }
   //   str[w]=Link.store;

      return bf_string;
   }

   public String links(String string){


   String fstring="";
   String store="";
   String id="";
   String title="";
   fstring=string+' ';//
   int i=0,j=0,h=0,g=0; //counting
   int k=fstring.length();
   int check=0,check2=0,check3=0,check4=0,check5=0,checkCase=0,rCheck=0,rCheck2=0;
   int ok=0;
   int a=0, b=0;


   //inline case
   for(i=0;i<k;i++){

      if(fstring.charAt(i)=='['){
         check=i;System.out.println(check);
         for(j=i+1;j<k;j++){
            if(fstring.charAt(j)==']'){
               check2=j;
               if(fstring.charAt(j+1)==':'){
                  checkCase=2; //check implicit link
                  break;
               }
               for(h=j+1;h<k;h++){
                  if(fstring.charAt(h)=='['){
                     rCheck=h;

                     for(g=h+1;g<k;g++){

                        if(fstring.charAt(g)==']'){
                           rCheck2=g;
                           checkCase=1;
                           break;
                        }

                     }
                  }
               }
            break;
            }
         }
      break;
      }

   }

   if(fstring.charAt(check2+1)=='('|| fstring.charAt(check2+1)==':'){


      if(fstring.charAt(check2+2)=='h'){
         check3=check2+2;
         if(fstring.charAt(check2+3)=='t'){
            if(fstring.charAt(check2+4)=='t'){
               if(fstring.charAt(check2+5)=='p'){
                  ok=1;
               }
            }
         }
      }
   }


   check5=fstring.indexOf('"', check2)-1; //���� Ȯ��
   if(check3!=0){
      for(i=check3; i<k; i++){
         if(fstring.charAt(i)==')'){
            check4=i;
            if(fstring.charAt(i-1)=='"' && ok==1 && fstring.charAt(check5)==' '){
               ok=2;
            }
         }
      }
   }


   if(ok==1 && checkCase==0){ //title�� ���� ���
      fstring=fstring.substring(0,check)+"<a href=\""+fstring.substring(check3,check4)+"\">"+fstring.substring(check+1,check2)+"</a>"+fstring.substring(check4+1);
      return fstring;
   }else if(ok==2 && checkCase==0){ //title�� �ִ� ���
      fstring=fstring.substring(0,check)+"<a href=\""+fstring.substring(check3,check5)+"\""+" title="+fstring.substring(check5+1,check4)+">"+fstring.substring(check+1,check2)+"</a>"+fstring.substring(check4+1);
      return fstring;

   }

//reference case

   if(checkCase==1){ //id and title
      id=fstring.substring(check,check2+1); //not case sensitive
      title=fstring.substring(rCheck,rCheck2+1);
   }


   if(checkCase==2){ //implicit link

      a=fstring.indexOf('"');
      b=fstring.indexOf('"',a+1);


      if(rCheck2-1==rCheck){ //when the second [] is empty
      //checking id �ڿ��� ������ id�� check �ؾ���

         if((fstring.substring(0,id.length())).compareTo(id)==0){

            if(a<0){
               store="<a href=\""+fstring.substring(id.length()+1)+"\">"+fstring.substring(check+1,check2)+"</a>";
            }else if(a>0){
               store="<a href=\""+fstring.substring(id.length()+1, a-1)+"\" title=\""+fstring.substring(a+1,b)+"\">"+fstring.substring(check+1,check2)+"</a>";
            }
         }

      }else{
      //checking title �ڿ��� ������ title�� �n

         string=fstring.substring(0,title.length()).toLowerCase(); //not case sensitive

         if(string.compareTo(title)==0){

            if(a<0){
               store="<a href=\""+fstring.substring(title.length()+1)+"\">"+fstring.substring(check+1,check2)+"</a>";
            }else if(a>0){
               store="<a href=\""+fstring.substring(title.length()+1, a-1)+"\" title=\""+fstring.substring(a+1,b)+"\">"+fstring.substring(check+1,check2)+"</a>";
            }
         }
      }
   }
   //�ٲ۰� id�ִ� �ٿ� �ִ� ���!!!

   return fstring;

   }


}
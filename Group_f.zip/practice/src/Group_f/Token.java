package Group_f;

import Group_f.Node.node;

public class Token implements MDElement {
	
	String str_p="", str_c="", str_n="";
	public void token(Node<String> contents){
		Image img = new Image();
		Link ln = new Link();
		//StyleText ST = new StyleText();
		node temp;
		temp = contents.head;
		//node prev=null;
				
		while(temp!=null){
			str_p="";
         	str_c="";
         	str_n="";
			if(temp.prev!=null)
				str_p=temp.prev.data;
			if(temp!=null)
				str_c=temp.data;
			if(temp.next!=null)
				str_n=temp.next.data;
			
			temp.data = img.image(str_c);
			temp.data = ln.Emphasis(str_c);
			//System.out.println("img success!");
			//System.out.println(ST.Emphasis(str_c));
			temp=temp.next;
		}
		
		System.out.println(contents);
	}
	public void accept(MDElementVisitor visitor) {
		
	}

}

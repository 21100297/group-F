package Group_f;

public class QuotedBlock extends Node<String>  {

	protected int check_quo, pre, nex;
	protected String temp_str1, temp_str2, str_cur;
	private String str_c, str_p, str_n="";
	
	public void quoted(Node<String> contents){
		// ����Ʈ�� ����ִ� ���� �˻�, �ش� ���뿡 ���� Ư¡�� �Ʒ��Ͱ��� �˻��ؼ� ���� �ɵ��� 
		check_quo=0;
		pre = 0;
		nex = 0;
		temp_str1 = "";
		temp_str2 = "";
		
		node temp=contents.head;
		node prev=null;

	    int quot_num = 0;
	    int check_quo_n = 0;
	   
		while(temp!=null){ // ������ ����
         	check_quo=0;
         	temp_str1 = "";
         	temp_str2 = "";
         	str_p="";
         	str_c="";
         	str_n="";
         			
			/*System.out.println("����");
			if(temp.prev==null)
				System.out.println("��null");
			if(temp==null)
				System.out.println("��null");
			if(temp.next==null)
				System.out.println("��null");
			
			System.out.println("����2");*/
			if(temp.prev!=null)
				str_p=temp.prev.data;
				str_c=temp.data;
			if(temp.next!=null)
				str_n=temp.next.data;
				
	        if(!str_c.isEmpty()){
				
	        if(str_p.isEmpty() || ( pre==0 && nex==0 &&str_p.length()>=12 && !str_p.substring(0,12).contains("<blockquote>"))){ // �� �� ���ų� quoted�ƴ�
	        	if(str_n.isEmpty() || str_n.charAt(0)!='>'){ // �� �� ���ų� quoted�ƴ�
		        	if(str_c.charAt(0)=='>'){ // �����ٸ� quoted
		        		for(int i=0; i<str_c.length();i++){
		        			if(str_c.charAt(i)=='>'){
		        				check_quo++;     
	        				}
		        			else
		        				break;   
			            }
		      		}
		        	
		        	if(check_quo>0){
		        		//System.out.println("�ֿ���?2");
		        		for(int j=0; j<check_quo;j++){
		        			if(j==0)
		        				temp_str1="<blockquote>";
	     	             	else
		     	                temp_str1+="<blockquote>";
		     	        }
		        		temp_str2=str_c.substring(check_quo);
		     	          
		        		for(int i=0; i<check_quo; i++){
		        			if(i == 0)
		        				temp_str2 += "</blockquote>";
		     	           	else
		     	           		temp_str2 += "</blockquote>";
	     	           	}
		        		this.str_cur = temp_str1+temp_str2;
		     	           	     	            
		        		temp.data=this.str_cur;
	     	       	} //���� ��ȯ �Ϸ�
		        	quot_num = 0;
		        	pre = 0;
		        	nex = 0;
		        }else{ // �� �� quoted
		        	if(str_c.charAt(0)=='>'){ // ������ quoted
			             for(int i=0; i<str_c.length();i++){
			                if(str_c.charAt(i)=='>'){
			                	check_quo++;     
			                }
			                else
			                	break;   
			             }
			       	}
		        	quot_num = check_quo;
		        	
		        	for(int i=0; i<str_n.length();i++){
		                if(str_n.charAt(i)=='>'){
		                	check_quo_n++;     
		                }
		                else
		                	break;   
		            }
		        	if(quot_num <= check_quo_n){ // �������� �����ٺ��� quoted ���� ���ų� ���� ��
		        		//System.out.println("�ֿ���?3");
		        		if(check_quo>0){
			        		for(int j=0; j<check_quo;j++){
			        			temp_str1+="<blockquote>";
			        		}   
			        		temp_str2 = str_c.substring(check_quo);
				    	          
			        		this.str_cur = temp_str1+temp_str2;				    	            	     	            
			        		temp.data = temp_str1+temp_str2;
			        	} //���� ��ȯ �Ϸ�
		        	}else{ // �������� �����ٺ��� quoted ���� ���� ��.
		        		//System.out.println("�ֿ���?4");
		           		if(check_quo>0){
			        		for(int j=0; j<check_quo;j++){
			        			temp_str1+="<blockquote>";
			        		}   
			        		temp_str2=str_c.substring(check_quo);
				    	    
			        		for(int i=0; i<(quot_num - check_quo_n); i++){
			        			temp_str2 += "</blockquote>";
		     	           	}
			        		
			        		this.str_cur = temp_str1+temp_str2;
				    	            	     	            
			        		temp.data=this.str_cur;
			        	} //���� ��ȯ �Ϸ�
		           		quot_num -= (quot_num-check_quo_n);
		        	}
		          	check_quo_n=0;
		          	pre = 0;
		          	nex = 1;
		        }
	        } 
	        else{ // �� �� quoted
	        	if(str_n.isEmpty() || str_n.charAt(0)!='>'){ // �� �� ���ų� quoted�ƴ�
		        	if(str_c.charAt(0)=='>'){ // �������� ������ quoted
		        		for(int i=0; i<str_c.length();i++){
		        			if(str_c.charAt(i)=='>'){
		        				check_quo++;     
	        				}
		        			else
		        				break;   
			            }	        			
		      		}
		        	if(quot_num < check_quo){
		        		//System.out.println("�ֿ���?5");
		        		if(check_quo>0){
		        			for(int i=0; i<(check_quo-quot_num); i++){
		     	           		temp_str1 += "<blockquote>";
	     	           		}
			        		temp_str2=str_c.substring(check_quo);
			     	          
			        		for(int i=0; i<check_quo; i++){
			     	           		temp_str2 += "</blockquote>";
		     	           	}
			        		this.str_cur = temp_str1+temp_str2;			     	           	     	            
			        		temp.data=this.str_cur;
		     	       	} //���� ��ȯ �Ϸ�
		        	}
		        	else if(quot_num == check_quo){
		        		//System.out.println("�ֿ���?6");
		        		if(check_quo>0){
			        		temp_str1="";
			        		temp_str2=str_c.substring(check_quo);
			     	          
			        		for(int i=0; i<check_quo; i++){
			     	           		temp_str2 += "</blockquote>";
		     	           	}
			        		this.str_cur = temp_str1+temp_str2;   	     	            
			        		temp.data=this.str_cur;
		     	       	} //���� ��ȯ �Ϸ�
		        	}
		        	pre = 1;
		        	nex = 0;
	        	}else{ // �� �� quoted ///���� ���� üũ��
		        	if(str_c.charAt(0)=='>'){ // ������ quoted
			             for(int i=0; i<str_c.length();i++){
			                if(str_c.charAt(i)=='>'){
			                	check_quo++;     
			                }
			                else
			                	break;   
			             }
			       	}
		        	//quot_num = check_quo;
		        	for(int i=0; i<str_n.length();i++){
	                	if(str_n.charAt(i)=='>')
	                		check_quo_n++;     
		                else
		                	break;   
		        	}
		        	
		        	if(check_quo <= check_quo_n){ // �������� �����ٺ��� quoted ���� ���ų� ���� ��
		        		//System.out.println("�ֿ���?7");
		        		if(check_quo>0){
			        		for(int j=0; j<(check_quo-quot_num);j++){
			        				temp_str1+="<blockquote>";
			        		}
			        		temp_str2=str_c.substring(check_quo);				    	           
			        		this.str_cur = temp_str1+temp_str2;				    	            	     	            
			        		temp.data=this.str_cur;
			        		quot_num = check_quo;
			        	} //���� ��ȯ �Ϸ�		        		
		        	}else{ // �������� �����ٺ��� quoted ���� ���� ��.
		        		//System.out.println("�ֿ���?8");
		           		if(check_quo>0){
		           			for(int i=0; i<(check_quo - quot_num); i++){
		     	           		temp_str1 += "<blockquote>";
		           			}
		           			
			        		temp_str2=str_c.substring(check_quo);
			        		for(int i=0; i<(check_quo - check_quo_n); i++){
			     	           		temp_str2 += "</blockquote>";
		     	           	}			        		
			        		this.str_cur = temp_str1+temp_str2;				    	            	     	            
			        		temp.data=this.str_cur;
			        	} //���� ��ȯ �Ϸ�
		           		quot_num -= (quot_num-check_quo_n);
		        	}
		        	check_quo_n=0;
		        	pre = 1;
		          	nex = 1;
	        	}
	        }
	        }
	        else{
	        	pre = 0;
          		nex = 0;
			}
	        prev=temp;
	        temp=temp.next;
         			
	    } // ���� ���� �˻�
		
	}
}

package Group_f;

public class Header_atx extends Header{
	
	public Header_atx(){		
	}
	
	public void accept(MDElementVisitor visitor){
		visitor.visitHeader_atx(this);
	}
}

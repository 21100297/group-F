package Group_f;

public class HorizontalRules extends Node<String> {

	public HorizontalRules() {

	}
	
	public void accept(MDElementVisitor visitor) {
		visitor.visitHorizontalRules(this);
	}
}
package Group_f;

//import java.util.LinkedList;
import java.io.*;

// ���α׷��� ���ư��� ���� �Լ� �κ�, ���⼭ ���ɾ �Է¹޴´�. 
public class MDPaser {
	public static Node<String> content = new Node<String>();

	public static void main(String[] args) throws java.io.IOException {
		Command command = new Command();
		PlainVisitor plain = new PlainVisitor();
		FancyVisitor fancy = new FancyVisitor();
		Document document = new Document();
		String file_name = "";
		String style = "";

		// Input Command ====================================================
		try {
			command.visitCommand(args[0]);
		} catch (Exception v) {
			System.out.println("Please Input command.");
			return;
		}
		// ===================================================================
		// Input File========================================================
		try {
			file_name = args[1];
			FileInputStream fileReader = new FileInputStream(file_name);
			BufferedReader read = new BufferedReader(new FileReader(file_name));
			String f_string = "";

			while ((f_string = read.readLine()) != null) // ������ string�� �߶�
			// �����մϴ�
			{
				content.addLast(f_string);
			}

		} catch (FileNotFoundException e) {
			System.out.println("Please Input Right File Name.");
			e.printStackTrace();
		}
		// Input Style========================================================
		style = args[args.length - 1];
		if (args[1].equals(style)) {
			document.FileRead(plain);
			FileWriter(file_name, content, "plain");

		} else {
			if (style.equals("plain")) {
				document.FileRead(plain);
				FileWriter(file_name, content, "plain");
				// plain class
			} else if (style.equals("fancy")) {
				document.FileRead(fancy);
				FileWriter(file_name, content, "fancy");
				// plain class
			} else if (style.equals("slide")) {
				System.out.print("Style: Slide Style");
				// slide class
			} else {
				System.out.print("Please, Input right type.");
			}
		}
	}

	public static void FileWriter(String File_name, Node<String> create_content, String visitor) throws IOException {

		int find = File_name.indexOf('.');
		FancyVisitor fancy_v = new FancyVisitor();

		File_name = File_name.substring(0, find);
		FileWriter reader = new FileWriter(File_name + ".html");

		if (visitor.equals("fancy")) {
			reader.write(fancy_v.start());

			try {
				while (create_content.head != null) { // ������ ����
					reader.write(create_content.head.data);
					create_content.head = content.head.next;
				}
				reader.write(fancy_v.end());
				reader.close();
			} catch (IOException ex) {
			}
		} // if ������ �κ�
		else if (visitor.equals("plain")) {
			reader.write("<html><body>\n");
			try {
				while (create_content.head != null) { // ������ ����
					reader.write(create_content.head.data);
					create_content.head = content.head.next;
				}
				reader.write("</body></html>\n");
				reader.close();
			} catch (IOException ex) {
			}
		}

	}
}

package Group_f;

public class Image extends Token {
	public Image() {
	}

	public void accept(MDElementVisitor visitor) {
		visitor.visitImage(this);
	}
}
package Group_f;

public class CodeBlock extends Node<String> {

	public CodeBlock() {		
	}

	public void accept(MDElementVisitor visitor) {
		visitor.visitCodeBlock(this);
	}

}// �ڵ���� ��ü class ǥ��

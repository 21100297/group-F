package Group_f;

//import Group_f.Node.node;
import Group_f.Node;
import Group_f.Node.node;

public class PlainVisitor implements MDElementVisitor {
	// Document dc = new Document();
	// private Node<String> contents = dc.getcontent();

	private String af_string;
	private String str_c, str_p, str_n;
	// private int header=0;

	Node<String> nd = new Node<String>();
	Header_atx head_a = new Header_atx();
	Header_setext head_s = new Header_setext();

	// READ MD FILE
	public void visitDocument(Document document) {
		System.out.print("Style: Plain Style\n");
	}

	// Separate Node
	public void visitNode(Node node) {
		System.out.println("We separate string to Node!");
	}

	@Override
	public void visitHeader(Header hd) {

	}

	@Override
	public void visitHeader_setext(Header_setext hs) {
		// TODO Auto-generated method stub

		Node<String>.node temp = MDPaser.content.head;
		Node<String>.node todoDeleted = null;

		int count_atx = 0;
		int count_set = 0;
		int check_ds = 0;

		while (temp != null) {
			count_atx = 0;
			count_set = 0;
			check_ds = 0;
			af_string = "";

			str_p = "";
			str_c = "";
			str_n = "";

			str_c = temp.data;
			if (temp.prev != null)
				str_p = temp.prev.data;
			if (temp.next != null)
				str_n = temp.next.data;

			if (!str_c.isEmpty()) {

				for (int i = 0; i < str_c.length(); i++) { // atx type header
					if (str_c.trim().charAt(i) == '#') { // checking front#
						count_atx++;
					} else if (i == 6 || str_c.trim().charAt(i) != '#') {
						break;
					}
				}

				if (temp.next != null) {
					for (int i = 0; i < str_n.length(); i++) {
						if (str_n.trim().charAt(i) == '=')
							count_set++;
						else
							break;
					}

					if (count_atx == 0 && !(str_c.isEmpty())) { // #�� ���� string
						if ((count_set != 0) && (count_set == str_n.length())) {

							// �Ⱦ��� ��(=====) �����մϴ�
							todoDeleted = temp.next; // ���� �ϱ� �� �ش� ������ ����
							temp.next = temp.next.next; // ���� ��� ��带 ���ῡ�� �и��մϴ�
							if (temp.next != null) {
								temp.next.prev = temp; // ������ ����� ���� ��带 �����մϴ�.
							}
							if (todoDeleted == nd.tail) {
								nd.tail = temp;
							}
							todoDeleted = null;
							MDPaser.content.length--;
							// ���� �Ϸ�
							check_ds = 7;
						}
					}

					if (count_set == 0) {
						for (int i = 0; i < str_n.length(); i++) {
							if (str_n.trim().charAt(i) == '-')
								count_set++;
							else
								break;
						}

						if (count_atx == 0 && !(str_c.isEmpty())) { // #�� ����
																	// string
							if ((count_set != 0) && (count_set == str_n.length())) {

								// �Ⱦ��� ��(=====) �����մϴ�
								todoDeleted = temp.next; // ���� �ϱ� �� �ش� ������ ����
								temp.next = temp.next.next; // ���� ��� ��带 ���ῡ��
															// �и��մϴ�
								if (temp.next != null) {
									temp.next.prev = temp; // ������ ����� ���� ��带
															// �����մϴ�.
								}
								if (todoDeleted == nd.tail) {
									nd.tail = temp;
								}
								todoDeleted = null;
								MDPaser.content.length--;
								// ���� �Ϸ�
								check_ds = 8;

							}
						} // #�� ���� string ��ȯ �Ϸ�
					} // -�� �ִ� string
					if (check_ds == 7) {
						af_string = "<h1>" + str_c.trim() + "</h1>";
						temp.data = af_string;
					} else if (check_ds == 8) {
						af_string = "<h2>" + str_c.trim() + "</h2>";
						temp.data = af_string;
					}
				}
			} // ��ü �˻� �Ϸ�
			temp = temp.next; // ���� ������ �д´� �б� �� �ʱ�ȭ �ʼ�
		}
	}

	@Override
	public void visitHeader_atx(Header_atx ha) {
		// TODO Auto-generated method stub

		Node<String>.node temp = MDPaser.content.head;
		int count_atx = 0;
		// af_string="";

		while (temp != null) {
			count_atx = 0;
			af_string = "";

			str_p = "";
			str_c = "";
			str_n = "";

			if (temp.prev != null)
				str_p = temp.prev.data;

			str_c = temp.data;
			if (temp.next != null)
				str_n = temp.next.data;

			if (!str_c.isEmpty()) {

				for (int i = 0; i < str_c.length(); i++) { // atx type header
					if (str_c.trim().charAt(i) == '#') { // checking front#
						count_atx++;
					} else if (i == 6 || str_c.trim().charAt(i) != '#') {
						break;
					}
				}
				if ((count_atx > 0) && (count_atx < 7)) {

					if (count_atx == 1) {
						af_string = "<h1>" + str_c.trim().substring(1) + "</h1>";
					} else if (count_atx == 2) {
						af_string = "<h2>" + str_c.trim().substring(2) + "</h2>";
					} else if (count_atx == 3) {
						af_string = "<h3>" + str_c.trim().substring(3) + "</h3>";
					} else if (count_atx == 4) {
						af_string = "<h4>" + str_c.trim().substring(4) + "</h4>";
					} else if (count_atx == 5) {
						af_string = "<h5>" + str_c.trim().substring(5) + "</h5>";
					} else if (count_atx == 6) {
						af_string = "<h6>" + str_c.trim().substring(6) + "</h6>";
					}
					temp.data = af_string;
				}
			} // ��ü �˻� �Ϸ�
			temp = temp.next; // ���� ������ �д´� �б� �� �ʱ�ȭ �ʼ�
		}
	}

	@Override
	public void visitHorizontalRules(HorizontalRules hr) {
		// TODO Auto-generated method stub
		Node<String>.node temp = MDPaser.content.head;

		String str_c, str_p;
		int size;
		int check;
		int blank;

		while (temp != null) {
			str_c = "";
			str_p = "";
			check = 0;
			blank = 0;

			str_c = temp.data;
			size = str_c.length();
			if (temp.prev != null)
				str_p = temp.prev.data;

			if (!str_c.isEmpty()) {
				if (str_p.equals("<br />")) {
					for (int i = 0; i < size; i++) {
						if (str_c.charAt(i) == '-' || str_c.charAt(i) == '*')
							check++;
						else if (str_c.charAt(i) == ' ')
							blank++;
						else
							break;
					}
					if (size == check + blank) {
						temp.data = "<hr />";
					}

				} else {
					for (int i = 0; i < size; i++) {
						if (str_c.charAt(i) == '*')
							check++;
						else if (str_c.charAt(i) == ' ')
							blank++;
						else
							break;
					}
					if (size == check + blank) {
						temp.data = "<hr />";
					}

				}
			}
			temp = temp.next;
		}
	}

	@Override
	public void visitItemList(ltemList il) {
		// TODO Auto-generated method stub

	}

	@Override
	public void visitOrderedList(OrderedList ol) {
		// TODO Auto-generated method stub

		Node<String>.node temp = MDPaser.content.head;

		int count_int_cur = 0;
		int check_dot_cur = 0;
		int count_int_next = 0;
		int check_dot_next = 0;
		int line = 0;
		int cur = 0;

		String temp_str1 = "", temp_str2 = "", temp_str3 = "";

		af_string = "";

		while (temp != null) {

			str_p = "";
			str_c = "";
			str_n = "";

			str_c = temp.data;
			if (temp.prev != null)
				str_p = temp.prev.data;
			if (temp.next != null)
				str_n = temp.next.data;
			// System.out.println(3);
			if (!str_c.isEmpty() && !str_c.equals("<br />")) {
				for (int i = 0; i < str_c.trim().length(); i++) {
					if (str_c.trim().charAt(i) == '0' || str_c.trim().charAt(i) == '1' || str_c.trim().charAt(i) == '2'
							|| str_c.trim().charAt(i) == '3' || str_c.trim().charAt(i) == '4'
							|| str_c.trim().charAt(i) == '5' || str_c.trim().charAt(i) == '6'
							|| str_c.trim().charAt(i) == '7' || str_c.trim().charAt(i) == '8'
							|| str_c.trim().charAt(i) == '9') {
						count_int_cur++;
					} else if ((count_int_cur > 0) && str_c.trim().charAt(i) == '.') {
						check_dot_cur = i;
						break;
					} else
						break;
				} // ���� ������ ���ڰ� �ִ��� ������ Ȯ��

				for (int i = 0; i < str_n.trim().length(); i++) {
					if (str_n.trim().charAt(i) == '0' || str_n.trim().charAt(i) == '1' || str_n.trim().charAt(i) == '2'
							|| str_n.trim().charAt(i) == '3' || str_n.trim().charAt(i) == '4'
							|| str_n.trim().charAt(i) == '5' || str_n.trim().charAt(i) == '6'
							|| str_n.trim().charAt(i) == '7' || str_n.trim().charAt(i) == '8'
							|| str_n.trim().charAt(i) == '9')
						count_int_next++;
					else if ((count_int_cur > 0) && str_n.trim().charAt(i) == '.') {
						check_dot_next = i;
						break;
					} else
						break;
				} // �����ٿ� ���ڰ� �ִ��� ������ üũ

				if (count_int_cur > 0 && (count_int_cur == check_dot_cur)) {
					if (cur == 1
							&& (!(str_n.length() == 0) && ((count_int_next) == check_dot_next) && count_int_next > 0)) {
						line = 0; // ��, �ڵ� Ordered
						cur = 1;
					} else if (cur == 0
							&& (!(str_n.length() == 0) && (count_int_next == check_dot_next) && count_int_next > 0)) {
						line = 1; // ���� plain, �ڴ� Ordered
						cur = 1;
					} else if (cur == 0 && ((str_n.equals("<br />")) || !((count_int_next) == check_dot_next))) {
						line = 2; // ȥ�ڼ� Ordered
						cur = 1;
					} else if (cur == 1 && ((str_n.equals("<br />")) || !((count_int_next) == check_dot_next)
							|| (count_int_next == 0))) {
						line = 3; // �� Ordered, �� plain
						cur = 1;
					}

					if (line == 0 && cur == 1) {
						temp_str1 = "<li>";
						temp_str2 = str_c.substring(count_int_cur + 2);
						temp_str3 = "</li>";
						temp.data = temp_str1 + temp_str2 + temp_str3;
					} else if (line == 1 && cur == 1) {
						temp_str1 = "<ol><li>";
						temp_str2 = str_c.substring(count_int_cur + 2);
						temp_str3 = "</li>";
						temp.data = temp_str1 + temp_str2 + temp_str3;
					} else if (line == 2 && cur == 1) {
						temp_str1 = "<ol><li>";
						temp_str2 = str_c.substring(count_int_cur + 2);
						temp_str3 = "</li></ol>";
						temp.data = temp_str1 + temp_str2 + temp_str3;
					} else if (line == 3 && cur == 1) {
						temp_str1 = "<li>";
						temp_str2 = str_c.substring(count_int_cur + 2);
						temp_str3 = "</li></ol>";
						temp.data = temp_str1 + temp_str2 + temp_str3;
					}
				} // ��ȯ�Ϸ�
				else
					cur = 0;
			} else
				cur = 0;// ����������� ���� ��� if�� ����

			temp = temp.next;

			count_int_cur = 0;
			check_dot_cur = 0;
			count_int_next = 0;
			check_dot_next = 0;
			line = 0;
			af_string = "";
		}
	}

	@Override
	public void visitUnorderedList(UnorderedList ul) {
		// TODO Auto-generated method stub
		Node<String>.node temp = MDPaser.content.head;

		int count_int_cur = 0;
		int check_dot_cur = 0;
		int count_int_next = 0;
		int check_dot_next = 0;
		int line = 0;
		int cur = 0;

		String temp_str1 = "", temp_str2 = "", temp_str3 = "";

		af_string = "";

		while (temp != null) {

			str_p = "";
			str_c = "";
			str_n = "";

			str_c = temp.data;
			if (temp.prev != null)
				str_p = temp.prev.data;
			if (temp.next != null)
				str_n = temp.next.data;
			// System.out.println(3);
			if (!str_c.isEmpty() && !str_c.equals("<br />")) {
				for (int i = 0; i < str_c.trim().length(); i++) {
					if (str_c.trim().charAt(i) == '*' || str_c.trim().charAt(i) == '+'
							|| str_c.trim().charAt(i) == '-') {
						count_int_cur++;
					} else if ((count_int_cur > 0) && str_c.trim().charAt(i) == ' ') {
						check_dot_cur = i;
						break;
					} else
						break;
				} // ���� ������ ���ڰ� �ִ��� ������ Ȯ��

				for (int i = 0; i < str_n.trim().length(); i++) {
					if (str_n.trim().charAt(i) == '*' || str_n.trim().charAt(i) == '+' || str_n.trim().charAt(i) == '-')
						count_int_next++;
					else if ((count_int_cur > 0) && str_n.trim().charAt(i) == ' ') {
						check_dot_next = i;
						break;
					} else
						break;
				} // �����ٿ� ���ڰ� �ִ��� ������ üũ

				if (count_int_cur > 0 && (count_int_cur == check_dot_cur)) {
					if (cur == 1 && (!(str_n.equals("<br />")) && (count_int_next == check_dot_next)
							&& count_int_next > 0)) {
						line = 0; // ��, �ڵ� Ordered
						cur = 1;
					} else if (cur == 0 && (!(str_n.equals("<br />")) && (count_int_next == check_dot_next)
							&& count_int_next > 0)) {
						line = 1; // ���� plain, �ڴ� Ordered
						cur = 1;
					} else if (cur == 0 && ((str_n.equals("<br />")) || !(count_int_next == check_dot_next))) {
						line = 2; // ȥ�ڼ� Ordered
						cur = 1;
					} else if (cur == 1 && ((str_n.equals("<br />")) || !(count_int_next == check_dot_next)
							|| (count_int_next == 0))) {
						line = 3; // �� Ordered, �� plain
						cur = 1;
					}

					if (line == 0 && cur == 1) {
						temp_str1 = "<li>";
						temp_str2 = str_c.substring(count_int_cur + 2);
						temp_str3 = "</li>";
						temp.data = temp_str1 + temp_str2 + temp_str3;
					} else if (line == 1 && cur == 1) {
						temp_str1 = "<ul><li>";
						temp_str2 = str_c.substring(count_int_cur + 2);
						temp_str3 = "</li>";
						temp.data = temp_str1 + temp_str2 + temp_str3;
					} else if (line == 2 && cur == 1) {
						temp_str1 = "<ul><li>";
						temp_str2 = str_c.substring(count_int_cur + 2);
						temp_str3 = "</li></ul>";
						temp.data = temp_str1 + temp_str2 + temp_str3;
					} else if (line == 3 && cur == 1) {
						temp_str1 = "<li>";
						temp_str2 = str_c.substring(count_int_cur + 2);
						temp_str3 = "</li></ul>";
						temp.data = temp_str1 + temp_str2 + temp_str3;
					}
				} // ��ȯ�Ϸ�
				else
					cur = 0;
			} else
				cur = 0;// ����������� ���� ��� if�� ����

			temp = temp.next;

			count_int_cur = 0;
			check_dot_cur = 0;
			count_int_next = 0;
			check_dot_next = 0;
			line = 0;
			af_string = "";
		}
	}

	@Override
	public void visitQuotedBlock(QuotedBlock qb) {
		// TODO Auto-generated method stub
		int check_quo = 0;
		int pre = 0;
		int nex = 0;
		String temp_str1 = "";
		String temp_str2 = "";

		Node<String>.node temp = MDPaser.content.head;
		// Node<String>.node prev=null;
		int quot_num = 0;
		int check_quo_n = 0;

		while (temp != null) { // ������ ����
			check_quo = 0;
			temp_str1 = "";
			temp_str2 = "";
			str_p = "";
			str_c = "";
			str_n = "";
			String str_cur = "";

			if (temp.prev != null)
				str_p = temp.prev.data;
			str_c = temp.data;
			if (temp.next != null)
				str_n = temp.next.data;

			if (!str_c.isEmpty() && !str_c.equals("<br />")) {

				if (str_p == null || str_p.isEmpty() || str_p.equals("<br />") || (pre == 0 && nex == 0
						&& str_p.length() >= 12 && !str_p.substring(0, 12).contains("<blockquote>"))) { // ��
																										// ��
																										// ���ų�
																										// quoted�ƴ�
					if (str_n.isEmpty() || str_n.charAt(0) != '>') { // �� �� ���ų�
																		// quoted�ƴ�
						if (str_c.charAt(0) == '>') { // �����ٸ� quoted
							for (int i = 0; i < str_c.length(); i++) {
								if (str_c.charAt(i) == '>') {
									check_quo++;
								} else
									break;
							}
						}

						if (check_quo > 0) {
							// System.out.println("�ֿ���?2");
							for (int j = 0; j < check_quo; j++) {
								if (j == 0)
									temp_str1 = "<blockquote>";
								else
									temp_str1 += "<blockquote>";
							}
							temp_str2 = str_c.substring(check_quo);

							for (int i = 0; i < check_quo; i++) {
								if (i == 0)
									temp_str2 += "</blockquote>";
								else
									temp_str2 += "</blockquote>";
							}
							temp.data = temp_str1 + temp_str2;
						} // ���� ��ȯ �Ϸ�
						quot_num = 0;
						pre = 0;
						nex = 0;
					} else { // �� �� quoted
						if (str_c.charAt(0) == '>') { // ������ quoted
							for (int i = 0; i < str_c.length(); i++) {
								if (str_c.charAt(i) == '>') {
									check_quo++;
								} else
									break;
							}
						}
						quot_num = check_quo;

						for (int i = 0; i < str_n.length(); i++) {
							if (str_n.charAt(i) == '>') {
								check_quo_n++;
							} else
								break;
						}
						if (quot_num <= check_quo_n) { // �������� �����ٺ��� quoted ����
														// ���ų� ���� ��
							// System.out.println("�ֿ���?3");
							if (check_quo > 0) {
								for (int j = 0; j < check_quo; j++) {
									temp_str1 += "<blockquote>";
								}
								temp_str2 = str_c.substring(check_quo);
								temp.data = temp_str1 + temp_str2;
							} // ���� ��ȯ �Ϸ�
						} else { // �������� �����ٺ��� quoted ���� ���� ��.
									// System.out.println("�ֿ���?4");
							if (check_quo > 0) {
								for (int j = 0; j < check_quo; j++) {
									temp_str1 += "<blockquote>";
								}
								temp_str2 = str_c.substring(check_quo);

								for (int i = 0; i < (quot_num - check_quo_n); i++) {
									temp_str2 += "</blockquote>";
								}

								temp.data = temp_str1 + temp_str2;
							} // ���� ��ȯ �Ϸ�
							quot_num -= (quot_num - check_quo_n);
						}
						check_quo_n = 0;
						pre = 0;
						nex = 1;
					}
				} else { // �� �� quoted
					if (str_n.isEmpty() || str_n.charAt(0) != '>') { // �� �� ���ų�
																		// quoted�ƴ�
						if (str_c.charAt(0) == '>') { // �������� ������ quoted
							for (int i = 0; i < str_c.length(); i++) {
								if (str_c.charAt(i) == '>') {
									check_quo++;
								} else
									break;
							}
						}
						if (quot_num < check_quo) {
							// System.out.println("�ֿ���?5");
							if (check_quo > 0) {
								for (int i = 0; i < (check_quo - quot_num); i++) {
									temp_str1 += "<blockquote>";
								}
								temp_str2 = str_c.substring(check_quo);

								for (int i = 0; i < check_quo; i++) {
									temp_str2 += "</blockquote>";
								}
								str_cur = temp_str1 + temp_str2;
								temp.data = str_cur;
							} // ���� ��ȯ �Ϸ�
						} else if (quot_num == check_quo) {
							// System.out.println("�ֿ���?6");
							if (check_quo > 0) {
								temp_str1 = "";
								temp_str2 = str_c.substring(check_quo);

								for (int i = 0; i < check_quo; i++) {
									temp_str2 += "</blockquote>";
								}
								str_cur = temp_str1 + temp_str2;
								temp.data = str_cur;
							} // ���� ��ȯ �Ϸ�
						}
						pre = 1;
						nex = 0;
					} else { // �� �� quoted ///���� ���� üũ��
						if (str_c.charAt(0) == '>') { // ������ quoted
							for (int i = 0; i < str_c.length(); i++) {
								if (str_c.charAt(i) == '>') {
									check_quo++;
								} else
									break;
							}
						}
						// quot_num = check_quo;
						for (int i = 0; i < str_n.length(); i++) {
							if (str_n.charAt(i) == '>')
								check_quo_n++;
							else
								break;
						}

						if (check_quo <= check_quo_n) { // �������� �����ٺ��� quoted ����
														// ���ų� ���� ��
							// System.out.println("�ֿ���?7");
							if (check_quo > 0) {
								for (int j = 0; j < (check_quo - quot_num); j++) {
									temp_str1 += "<blockquote>";
								}
								temp_str2 = str_c.substring(check_quo);
								str_cur = temp_str1 + temp_str2;
								temp.data = str_cur;
								quot_num = check_quo;
							} // ���� ��ȯ �Ϸ�
						} else { // �������� �����ٺ��� quoted ���� ���� ��.
									// System.out.println("�ֿ���?8");
							if (check_quo > 0) {
								for (int i = 0; i < (check_quo - quot_num); i++) {
									temp_str1 += "<blockquote>";
								}

								temp_str2 = str_c.substring(check_quo);
								for (int i = 0; i < (check_quo - check_quo_n); i++) {
									temp_str2 += "</blockquote>";
								}
								str_cur = temp_str1 + temp_str2;
								temp.data = str_cur;
							} // ���� ��ȯ �Ϸ�
							quot_num -= (quot_num - check_quo_n);
						}
						check_quo_n = 0;
						pre = 1;
						nex = 1;
					}
				}
			} else if (str_c.equals("<br />")) {
				pre = 0;
				nex = 0;
			}
			// prev=temp;
			temp = temp.next;

		} // ���� ���� �˻�
	}

	@Override
	public void visitCodeBlock(CodeBlock cb) {
		// TODO Auto-generated method stub
		// ����Ʈ�� ����ִ� ���� �˻�, �ش� ���뿡 ���� Ư¡�� �Ʒ��Ͱ��� �˻��ؼ� ���� �ɵ���

		int check_cur;
		int check_next;
		int check_cb;
		int line;
		int pre = 0;
		// String exchange_s = "";
		String temp_str1 = "", temp_str2 = "";

		Node<String>.node temp = MDPaser.content.head;

		while (temp != null) {

			str_p = "";
			str_c = "";
			str_n = "";
			check_cur = 0;
			check_next = 0;
			check_cb = 0;
			line = 0;
			// exchange_s = "";

			if (temp.prev != null)
				str_p = temp.prev.data;
			str_c = temp.data;
			if (temp.next != null)
				str_n = temp.next.data;
			if (!str_c.isEmpty() && !str_c.equals("<br />")) {
				if (str_p == null || pre == 0) { // ���� ���ų� codeblock�ƴ�
					for (int i = 0; i < str_c.length(); i++) {
						if (i == 4)
							break;
						if (str_c.charAt(i) == ' ')
							check_cur++;
					} // ���� ���� ����� ��
					for (int j = 0; j < str_n.length(); j++) {
						if (j == 4)
							break;
						if (str_n.charAt(j) == ' ')
							check_next++;
					} // ������ ����� ��
					if (!(str_n.isEmpty()) && (str_n.charAt(0) == '\t' || check_next == 4)) {// ����
																								// codeblock
						if (str_c.charAt(0) == '\t' || check_cur == 4) {
							if (str_c.charAt(0) == '\t')
								check_cb = 1;
							else if (check_cur == 4)
								check_cb = 2;
							pre = 1; // ������ codeblock
						}
					} else { // ���� plain
						if (str_c.charAt(0) == '\t' || check_cur == 4) {
							// ���� codeblock
							if (str_c.charAt(0) == '\t')
								check_cb = 1;// tab
							else if (check_cur == 4)
								check_cb = 2;// ���� 4��
							line = 2;
							pre = 1;
						}
					} // ���� plain ����
				} else { // ���� �ڵ����..?!
					for (int i = 0; i < str_c.length(); i++) {
						if (i == 4)
							break;
						if (str_c.charAt(i) == ' ')
							check_cur++;
					} // ���� ���� ����� ��
					for (int i = 0; i < str_n.length(); i++) {
						if (i == 4)
							break;
						if (str_n.charAt(i) == ' ')
							check_next++;
					} // ������ ����� ��
					if (!(str_n.isEmpty()) && (str_n.charAt(0) == '\t' || check_next == 4)) {// ����
																								// codeblock
						pre = 0;
						if (str_c.charAt(0) == '\t' || check_cur == 4) {
							// ���� codeblock
							if (str_c.charAt(0) == '\t')
								check_cb = 1;
							else if (check_cur == 4)
								check_cb = 2;
							line = 1; // ���ٵ� codeblock
							pre = 1;
						}
					} // ���� Ư¡���� ��� ����
					else { // ���� plain
						pre = 0;
						if (str_c.charAt(0) == '\t' || check_cur == 4) {
							// ���� codeblock
							if (str_c.charAt(0) == '\t')
								check_cb = 1;// tab
							else if (check_cur == 4)
								check_cb = 2;// ���� 4��
							line = 3; // ���ٵ� codeblock
							pre = 1;
						}
					} // ���� plain ����
				}

				if (line == 0) {
					if (check_cb == 1) {
						temp_str1 = "<pre><code>";
						temp_str2 = str_c.substring(1);
						temp.data = temp_str1 + temp_str2;
					} else if (check_cb == 2) {
						temp_str1 = "<pre><code>";
						temp_str2 = str_c.substring(4);
						temp.data = temp_str1 + temp_str2;
					}
				} else if (line == 1) {
					if (check_cb == 1) {
						temp_str1 = "";
						temp_str2 = str_c.substring(1);
						temp.data = temp_str1 + temp_str2;
					} else if (check_cb == 2) {
						temp_str1 = "";
						temp_str2 = str_c.substring(4);
						temp.data = temp_str1 + temp_str2;
					}
				} else if (line == 2) {
					if (check_cb == 1) {
						temp_str1 = "<pre><code>";
						temp_str2 = str_c.substring(1) + "</code></pre>";
						temp.data = temp_str1 + temp_str2;
					} else if (check_cb == 2) {
						temp_str1 = "<pre><code>";
						temp_str2 = str_c.substring(4) + "</code></pre>";
						temp.data = temp_str1 + temp_str2;
					}
				} else {
					if (check_cb == 1) {
						temp_str1 = "";
						temp_str2 = str_c.substring(1) + "</code></pre>";
						temp.data = temp_str1 + temp_str2;
					} else if (check_cb == 2) {
						temp_str1 = "";
						temp_str2 = str_c.substring(4) + "</code></pre>";
						temp.data = temp_str1 + temp_str2;
					}
				}
			} else {
				pre = 0;
			}
			temp = temp.next;
			if (temp == null)
				break; // ������ ������� �� ������ break�� �������´�.
		}
	}

	@Override
	public void visitBlock(Block b) {
		// TODO Auto-generated method stub
		Node<String>.node temp = MDPaser.content.head;
		String str_c = "";
		String str_n = "";
		int check_cur;
		int check_next;
		int setex = 0;

		while (temp != null) {

			check_cur = 0;
			check_next = 0;

			str_c = temp.data;
			if (temp.next != null) {
				str_n = temp.next.data;
				for (int i = 0; i < str_n.length(); i++) {
					if (str_n.charAt(i) == '=' || str_n.charAt(i) == '-')
						check_next++;
				}

			}
			// �����Ͱ� ���� ���
			if (str_c.length() > 1 && (check_next < 3 || check_next != str_n.length()) && setex == 0) {
				for (int i = 0; i < str_c.length(); i++) {
					if (i == 4)
						break;
					if (str_c.charAt(i) == ' ')
						check_cur++;
				}
				if (str_c.length() > 1) {

				}

				if (str_c.charAt(0) != '#' && str_c.charAt(0) != '>' && str_c.charAt(0) != '\t' && check_cur != 4) // 1����
				// �Ÿ��ϴ�
				{ // quotedblock�� header�� ��� ����(axt)
					if (str_c.charAt(0) == '-' || str_c.charAt(0) == '*' || str_c.charAt(0) == '+') // itemListó��
																									// ����������
																									// ���ܻ���
					{ // item ����Ʈ�� ��� �׳� �÷����� �Ǵ� ����
						if ((str_c.charAt(1) != ' ' && str_c.charAt(1) != '-' && str_c.charAt(1) != '*'
								&& str_c.charAt(1) != '+')) {
							str_c = "<p>" + str_c;
							str_c += "</p>";
							temp.data = str_c;
						} else if ((str_c.charAt(1) == '-') || (str_c.charAt(1) == '*') || (str_c.charAt(1) == '+')) {
							if (str_c.length() == 2) {
								str_c = "<p>" + str_c;
								str_c += "</p>";
								temp.data = str_c;
							} else {
								for (int i = 2; i < str_c.length(); i++) {
									if ((str_c.charAt(i) != ' ') && (str_c.charAt(i) != '-') && (str_c.charAt(i) != '*')
											&& (str_c.charAt(i) != '+')) {
										str_c = "<p>" + str_c;
										str_c += "</p>";
										temp.data = str_c;
										break;
									}
								}
							}
						}

					} else if (str_c.trim().charAt(0) == '0' || str_c.trim().charAt(0) == '1'
							|| str_c.trim().charAt(0) == '2' || str_c.trim().charAt(0) == '3'
							|| str_c.trim().charAt(0) == '4' || str_c.trim().charAt(0) == '5'
							|| str_c.trim().charAt(0) == '6' || str_c.trim().charAt(0) == '7'
							|| str_c.trim().charAt(0) == '8' || str_c.trim().charAt(0) == '9')// ordered
																								// list��
																								// ���
																								// ����
					{ // ������ �ִ� list�� ��� ���ڰ� ù��°�� �������� �ڿ� ���� ������ �׳� �������� ���
						if (str_c.trim().charAt(1) != '.') {
							str_c = "<p>" + str_c;
							str_c += "</p>";
							temp.data = str_c;
						}
					} else if (str_c.trim().charAt(0) == '*' || str_c.trim().charAt(0) == '+'
							|| str_c.trim().charAt(0) == '-')// unordered list
																// ��� ����
					{ // ������ ���� list�� ���
						if (str_c.charAt(1) != ' ') {
							str_c = "<p>" + str_c;
							str_c += "</p>";
							temp.data = str_c;
						} else
							break;
					}
					// ������ string������ �ڿ� setext�� �Ǵ� ��� ����
					else if (str_c.charAt(0) != '-' || str_c.charAt(0) != '*' || str_c.charAt(0) != '+'
							|| str_c.trim().charAt(0) != '0' || str_c.trim().charAt(0) != '1'
							|| str_c.trim().charAt(0) != '2' || str_c.trim().charAt(0) != '3'
							|| str_c.trim().charAt(0) != '4' || str_c.trim().charAt(0) != '5'
							|| str_c.trim().charAt(0) != '6' || str_c.trim().charAt(0) != '7'
							|| str_c.trim().charAt(0) != '8' || str_c.trim().charAt(0) != '9') {
						str_c = "<p>" + str_c;
						str_c += "</p>";
						temp.data = str_c;
					} // ������ ��� ��ȯ �Ϸ�
				} // ��ü ����� ��

			} else if (str_c.length() == 1 && (check_next != 3 || check_next != str_n.length())) {
				str_c = "<p>" + str_c;
				str_c += "</p>";
				temp.data = str_c;
			} else if (str_c.isEmpty()) {
				temp.data = "<br />";
			} else if (check_next >= 3 && check_next == str_n.length()) {
				setex = 1;
			} else if (setex == 1) {
				setex = 0;
			}

			temp = temp.next; // ���� ���� �˻�
		}
	}

	@Override
	public void visitToken(Token t) {
		// TODO Auto-generated method stub

	}

	@Override
	public void visitImage(Image i) {
		// TODO Auto-generated method stub
		// ![Alt text](/path/to/img.jpg)
		// [id]: url/to/image �̹��� syntax. [id] �Ⱦ��ٰ� ����
		Node<String>.node temp = MDPaser.content.head;

		while (temp != null) {
			str_c = temp.data;
			String a = "";
			String temp1 = "", temp2 = "", temp3 = "", temp4 = "";

			int str_length = str_c.length();
			for (int i1 = 0; i1 < str_length; i1++) {
				if (i1 == str_length - 4)
					break;
				else if (str_c.charAt(i1) == '!' && str_c.charAt(i1 + 1) == '[') {
					for (int j = i1 + 2; j < str_length; j++) {
						if (j == str_length - 2)
							break;
						else if (str_c.charAt(j) == ']' && str_c.charAt(j + 1) == '(' && j != i1 + 2) {
							for (int m = j + 2; m < str_length; m++) {
								if (str_c.charAt(m) == ')' && m != j + 2) { // ����.
																			// ��
																			// ��츸
																			// �����Ѵٰ�
																			// ����
									temp1 = str_c.substring(0, i1);
									temp2 = "<img alt=" + '"' + str_c.substring(i1 + 2, j) + '"';
									temp3 = "src=" + '"' + str_c.substring(j + 2, m) + '"' + ">";
									temp4 = str_c.substring(m + 1);
								}
							}
						}
						/*
						 * else if(str_c.charAt(j)==']'&& str_c.charAt(j+1)=='['
						 * && j!=i+2){ for(int n=j+2; n<str_length; n++){
						 * if(str_c.charAt(n)==']' && n!=j+2){ // ����. �Ⱦ��ٰ� ����
						 * 
						 * } } }
						 */
					}
				}
			}
			a = temp1 + temp2 + temp3 + temp4;
			if (!a.equals(""))
				temp.data = a;
			temp.data = str_c;
			temp = temp.next;
		}

	}

	@Override
	public void visitLink(Link l) {
		// TODO Auto-generated method stub
		Node<String>.node temp = MDPaser.content.head;
		int line = 0;
		int lineKeep = -1;
		while (temp != null) {
			String string = "";
			String fstring = "";
			String store = "";
			String id = "";
			String title = "";

			string = temp.data;

			fstring = string + ' ';//
			int i = 0, j = 0, h = 0, g = 0; // counting
			int k = fstring.length();
			int check = 0, check2 = 0, check3 = 0, check4 = 0, check5 = 0, checkCase = 0, rCheck = 0, rCheck2 = 0;
			int ok = 0;
			int a = 0, b = 0;

			// inline case
			for (i = 0; i < k; i++) {

				if (fstring.charAt(i) == '[') {
					check = i;
					System.out.println(check);
					for (j = i + 1; j < k; j++) {
						if (fstring.charAt(j) == ']') {
							check2 = j;
							if (fstring.charAt(j + 1) == ':') {
								checkCase = 2; // check implicit link
								break;
							}
							for (h = j + 1; h < k; h++) {
								if (fstring.charAt(h) == '[') {
									rCheck = h;

									for (g = h + 1; g < k; g++) {

										if (fstring.charAt(g) == ']') {
											rCheck2 = g;
											checkCase = 1;
											break;
										}

									}
								}
							}
							break;
						}
					}
					break;
				}

			}

			if (fstring.charAt(check2 + 1) == '(' || fstring.charAt(check2 + 1) == ':') {

				if (fstring.charAt(check2 + 2) == 'h') {
					check3 = check2 + 2;
					if (fstring.charAt(check2 + 3) == 't') {
						if (fstring.charAt(check2 + 4) == 't') {
							if (fstring.charAt(check2 + 5) == 'p') {
								ok = 1;
							}
						}
					}
				}
			}

			check5 = fstring.indexOf('"', check2) - 1; // ���� Ȯ��
			if (check3 != 0) {
				for (i = check3; i < k; i++) {
					if (fstring.charAt(i) == ')') {
						check4 = i;
						if (fstring.charAt(i - 1) == '"' && ok == 1 && fstring.charAt(check5) == ' ') {
							ok = 2;
						}
					}
				}
			}

			if (ok == 1 && checkCase == 0) { // title�� ���� ���
				fstring = fstring.substring(0, check) + "<a href=\"" + fstring.substring(check3, check4) + "\">"
						+ fstring.substring(check + 1, check2) + "</a>" + fstring.substring(check4 + 1);
				temp.data = fstring;
			} else if (ok == 2 && checkCase == 0) { // title�� �ִ� ���
				fstring = fstring.substring(0, check) + "<a href=\"" + fstring.substring(check3, check5) + "\""
						+ " title=" + fstring.substring(check5 + 1, check4) + ">" + fstring.substring(check + 1, check2)
						+ "</a>" + fstring.substring(check4 + 1);
				temp.data = fstring;

			}
			temp = temp.next;
		}

	}

	@Override
	public void visitPlainText(PlainText pt) {
		// TODO Auto-generated method stub

	}

	public void visitStyleText(StyleText st) {
		StyleText_emphasis SE = new StyleText_emphasis();
		Node<String>.node temp = MDPaser.content.head;

		while (temp != null) {
			int e = 0;
			str_c = temp.data;

			for (e = 0; e < 10; e++) {
				// System.out.println("e: " + e);
				str_c = SE.emphasis(str_c, "", "");
			}
			temp.data = str_c;
			temp = temp.next;
			str_c = "";
		}
	}

	@Override
	public void visitStyleText_emphasis(StyleText_emphasis se) {
	}
}

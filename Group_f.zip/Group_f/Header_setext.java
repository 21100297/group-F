package Group_f;

public class Header_setext extends Header {

	public Header_setext(){
	}
	
	public void accept(MDElementVisitor visitor){
		visitor.visitHeader_setext(this);
	}
	
}

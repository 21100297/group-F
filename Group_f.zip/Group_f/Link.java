package Group_f;

public class Link extends Token {

	public Link() {
	}

	public void accept(MDElementVisitor visitor) {
		visitor.visitLink(this);
	}

}
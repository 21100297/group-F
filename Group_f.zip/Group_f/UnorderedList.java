package Group_f;

public class UnorderedList extends ltemList {

	public UnorderedList() {		
	}

	public void accept(MDElementVisitor visitor) {
		visitor.visitUnorderedList(this);
	}

}

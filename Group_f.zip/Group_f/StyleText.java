package Group_f;

public class StyleText extends Token {

	public void accept(MDElementVisitor visitor){
		visitor.visitStyleText(this);
	}


}
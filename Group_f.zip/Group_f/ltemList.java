package Group_f;

public class ltemList extends Node<String> {

	public ltemList(){
	} 	
	
	public void accept(MDElementVisitor visitor) {
		visitor.visitItemList(this);
	}

} // ��ü class ��

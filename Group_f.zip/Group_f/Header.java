package Group_f;

public class Header extends Node<String> {
	
	public Header(){		
	}
	
	public void accept(MDElementVisitor visitor){
		visitor.visitHeader(this);
	}
} // ��ü class �����Դϴ� 

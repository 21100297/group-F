package Group_f;

import java.io.*;

public class Document implements MDElement {
	// public Node<String> content=new Node<String>();

	// private String file_name="";

	public void FileRead(MDElementVisitor visitor) throws IOException {

		CodeBlock CB = new CodeBlock();
		QuotedBlock QB = new QuotedBlock();
		Header_atx HA = new Header_atx();
		Header_setext HS = new Header_setext();
		HorizontalRules HR = new HorizontalRules();
		Block BL = new Block();
		OrderedList OL = new OrderedList();
		UnorderedList UL = new UnorderedList();
		Token TK = new Token();
		
		BL.accept(visitor);
		CB.accept(visitor);
		QB.accept(visitor);
		HR.accept(visitor);
		OL.accept(visitor);
		UL.accept(visitor);
		HA.accept(visitor);
		HS.accept(visitor);
		// ����Ʈ�� ������ Ȯ���Ѵ�.
		TK.token(visitor);
		//System.out.println(MDPaser.content + "3");
	}

	public void accept(MDElementVisitor visitor) {
		visitor.visitDocument(this);
	}

}

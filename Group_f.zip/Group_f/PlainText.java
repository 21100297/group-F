package Group_f;

public class PlainText extends Token{
	public void accept(MDElementVisitor visitor){
		visitor.visitPlainText(this);
	}

}

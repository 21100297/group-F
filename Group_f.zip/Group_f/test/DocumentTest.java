package Group_f.test;

//import static org.junit.Assert.*;

import java.io.BufferedReader;
import java.io.IOException;

import org.junit.Before;
import org.junit.Test;

import Group_f.MDPaser;
//import Group_f.Document;
import org.junit.After;

public class DocumentTest {

	//private Document doc;
	//private MDPaser md;
	String str0[]={"-read","E:\\workspace\\practice\\src\\save.txt","fancy"};
	String str1[]={"-read","E:\\workspace\\practice\\src\\save.txt","plain"};
	String str2[]={"-read","E:\\workspace\\practice\\src\\code.txt","plain"};
	String str3[]={"-read","E:\\workspace\\practice\\src\\header.txt","plain"};
	String str4[]={"-read","E:\\workspace\\practice\\src\\image.txt","plain"};
	String str5[]={"-read","E:\\workspace\\practice\\src\\block.txt","plain"};
	String str6[]={"-read","E:\\workspace\\practice\\src\\itemlist.txt","plain"};
	String str7[]={"-read","E:\\workspace\\practice\\src\\horizon.txt","plain"};
	String str8[]={"-read","E:\\workspace\\practice\\src\\quoted.txt","plain"};
	BufferedReader in = null;
	   
	@Before
	public void setup() {	       
		System.out.println("setup");
	}
	   
	@After
	public void teardown() {
		System.out.println("teardown!!!");
	}

	@Test
	public void testFileRead1() throws IOException {
		MDPaser.main(str0);
		/*MDPaser.main(str2);
		MDPaser.main(str3);
		MDPaser.main(str4);
		MDPaser.main(str5);
		MDPaser.main(str6);
		MDPaser.main(str7);*/
		//fail("Not yet implemented");
	}
	/*@Test
	public void testFileRead2() throws IOException {
		//System.out.println("22");
		MDPaser.main(str2);
		
		//fail("Not yet implemented");
	}
	@Test
	public void testFileRead3() throws IOException {
		//System.out.println("33");
		MDPaser.main(str3);
		
		//fail("Not yet implemented");
	}
	@Test
	public void testFileRead4() throws IOException {
		//System.out.println("44");
		MDPaser.main(str4);
		
		//fail("Not yet implemented");
	}
	@Test
	public void testFileRead5() throws IOException {
		MDPaser.main(str5);
		//fail("Not yet implemented");
	}
	@Test
	public void testFileRead6() throws IOException {
		MDPaser.main(str6);
		//fail("Not yet implemented");
	}
	@Test
	public void testFileRead7() throws IOException {
		MDPaser.main(str7);
		//fail("Not yet implemented");
	}*/
	
	@Test
	public void testFileWriter() {
		//fail("Not yet implemented");
	}

	@Test
	public void testAccept() {
		//fail("Not yet implemented");
	}

}

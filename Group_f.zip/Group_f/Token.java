package Group_f;

import Group_f.Node.node;

public class Token implements MDElement {
	
	public void token(MDElementVisitor visitor){
		Image img = new Image();
		Link ln = new Link();
		PlainText pt = new PlainText();
		StyleText st = new StyleText();
				
		img.accept(visitor);
		ln.accept(visitor);
		st.accept(visitor);
		pt.accept(visitor);
		//ln.link();
		
		
	
		//System.out.println(contents);
	}
	public void accept(MDElementVisitor visitor) {
		visitor.visitToken(this);
	}

}

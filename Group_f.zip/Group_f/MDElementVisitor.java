package Group_f;

public interface MDElementVisitor {
	void visitDocument(Document document);
	void visitNode(Node node);
	void visitHeader(Header hd);
	void visitHeader_setext(Header_setext hs);
	void visitHeader_atx(Header_atx ha);
	void visitHorizontalRules(HorizontalRules hr);
	void visitItemList(ltemList il);
	void visitOrderedList(OrderedList ol);
	void visitUnorderedList(UnorderedList ul);
	void visitQuotedBlock(QuotedBlock qb);
	void visitCodeBlock(CodeBlock cb);
	void visitBlock(Block b);
	void visitToken(Token t);
	void visitImage(Image i);
	void visitLink(Link l);
	void visitStyleText_emphasis(StyleText_emphasis se);
	void visitPlainText(PlainText pt);
	void visitStyleText(StyleText styleText);
	
}

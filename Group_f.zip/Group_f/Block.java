package Group_f;

public class Block extends Node<String> {

	public Block() {
	}

	public void accept(MDElementVisitor visitor) {
		visitor.visitBlock(this);
	}

}

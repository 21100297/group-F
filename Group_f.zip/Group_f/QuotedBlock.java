package Group_f;

public class QuotedBlock extends Node<String>  {
	
	public QuotedBlock(){	
	}
	
	public void accept(MDElementVisitor visitor){
		visitor.visitQuotedBlock(this);
	}
}

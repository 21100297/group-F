package Group_f;

public interface MDElement {
	void accept(MDElementVisitor visitor);
}

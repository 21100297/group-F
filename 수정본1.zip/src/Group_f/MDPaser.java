package Group_f;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.LinkedList;


// ���α׷��� ���ư��� ���� �Լ� �κ�, ���⼭ ���ɾ �Է¹޴´�. 
public class MDPaser {
	public static void main(String[] args) throws java.io.IOException
	{
		Command command=new Command();
		PlainVisitor plain=new PlainVisitor();
		Document document=new Document();
		Node node=new Node();
		
		String f_name="";	
		String style="";
		
		// Input Command ====================================================
			try{
				command.visitCommand(args[0]);
			}
			catch(Exception v){
				System.out.println("Please Input command.");
				return;
				}
		//===================================================================
		// Input File========================================================
			try{
				f_name=args[1];
				FileReader fileReader=new FileReader(f_name);
				BufferedReader read=new BufferedReader(new FileReader(f_name));			
			}
			catch (FileNotFoundException a) {
				System.out.println("Input right file name");
				return;
			}
		//  Input Style========================================================
			style=args[args.length-1];
			if(args[1].equals(style))
			{
				document.FileRead(args[1]);
				document.accept(plain);
				node.accept(plain);
			}
			else{
				if(style.equals("plain")){
					System.out.print("Style: Plain Style");
					// plain class
				}
				else if(style.equals("fancy")){
					System.out.print("Style: Fancy Style");
					// fancy class
				}
				else if(style.equals("slide")){
					System.out.print("Style: Slide Style");
					// slide class
				}
				else{
					System.out.print("Please, Input right type.");}	
				}
		
	}
}

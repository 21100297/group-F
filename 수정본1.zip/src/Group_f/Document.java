package Group_f;

import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.LinkedList;


public class Document implements MDElement {
	public Node<String> content=new Node<String>();
	private String file_name="";
	
	public void FileRead(String name)throws IOException{
	
		try{
			file_name=name;
			FileInputStream fileReader=new FileInputStream(file_name);
			BufferedReader read=new BufferedReader(new FileReader(file_name));
			
			String f_string="";			
			while((f_string=read.readLine())!= null) // ������ string�� �߶� �����մϴ� 
			{
				content.addFirst(f_string);
			}
			
			//string ����ؼ� list�� �� ���� Ȯ��
			System.out.println(content);
			
		}
		catch(FileNotFoundException e){
			System.out.println("������ �̸��� ��Ȯ�� �Է��� �ֽʽÿ�.");
			e.printStackTrace();
		} 		
		
	}
	
		
	
	public void accept(MDElementVisitor visitor){
			visitor.visitDocument(this);
		}
}
